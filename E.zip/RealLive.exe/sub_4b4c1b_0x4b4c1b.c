// 函数: sub_4b4c1b
// 地址: 0x4b4c1b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
*0xd02b4492 = fconvert.d(arg2)
int32_t eflags
int32_t result
result.b = __in_al_immb(0xcf, eflags)
*arg1
return result
