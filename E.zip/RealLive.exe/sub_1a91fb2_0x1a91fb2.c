// 函数: sub_1a91fb2
// 地址: 0x1a91fb2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1a91fc4(arg1, data_1c077a0)
