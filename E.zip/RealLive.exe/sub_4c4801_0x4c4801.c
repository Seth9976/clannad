// 函数: sub_4c4801
// 地址: 0x4c4801
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
entry_ebx:1.b = ror.b(entry_ebx:1.b, 1)
int32_t esi
int16_t ds
esi, ds = __lds_gprz_memp(*0x7b885000)
*(esi - 0x3776b3b0)
*(arg3 + 0x64) += (entry_ebx * arg1):1.b
undefined
