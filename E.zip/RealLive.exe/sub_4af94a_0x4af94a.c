// 函数: sub_4af94a
// 地址: 0x4af94a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool d_1 = test_bit(__return_addr, 0xa)
arg2:1.b = 8
arg1[0xffffffd8] |= arg3:1.b
int32_t eflags
arg1.b = __in_al_immb(0x5b, eflags)
*arg5 - *arg6
void* esi
void* edi

if (d_1)
    esi = arg5 - 4
    edi = arg6 - 4
else
    esi = arg5 + 4
    edi = arg6 + 4

*(arg4 - 0x30) = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi - *edi
void* esi_1
void* edi_1

if (d_1)
    esi_1 = esi - 4
    edi_1 = edi - 4
else
    esi_1 = esi + 4
    edi_1 = edi + 4

*0x8b69d92 = 0x168c528f
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi_1 - *edi_1
void* esi_2
void* edi_2

if (d_1)
    esi_2 = esi_1 - 4
    edi_2 = edi_1 - 4
else
    esi_2 = esi_1 + 4
    edi_2 = edi_1 + 4

*0x8b69d92 = 0x18825c81
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi_2 - *edi_2
void* esi_3
void* edi_3

if (d_1)
    esi_3 = esi_2 - 4
    edi_3 = edi_2 - 4
else
    esi_3 = esi_2 + 4
    edi_3 = edi_2 + 4

*0x8b69d92 = 0x168c5c81
void* __return_addr_1
__return_addr_1.b = 0xcc
bool d = test_bit(arg8, 0xa)
arg2:1.b = 8
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi_3 - *edi_3
void* esi_4
void* edi_4

if (d)
    esi_4 = esi_3 - 4
    edi_4 = edi_3 - 4
else
    esi_4 = esi_3 + 4
    edi_4 = edi_3 + 4

*0x8b69d92 = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi_4 - *edi_4
void* esi_5
void* edi_5

if (d)
    esi_5 = esi_4 - 4
    edi_5 = edi_4 - 4
else
    esi_5 = esi_4 + 4
    edi_5 = edi_4 + 4

*0x8b69d92 = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi_5 - *edi_5
void* esi_6
void* edi_6

if (d)
    esi_6 = esi_5 - 4
    edi_6 = edi_5 - 4
else
    esi_6 = esi_5 + 4
    edi_6 = edi_5 + 4

*0x8b69d92 = 0x168c5c81
*(edi_6 - 0x29) |= arg1:1.b
*arg1 |= arg3.b
arg8 = 0xa75be4d8
*0x8b69d92 = 0x1c855c81
arg2:1.b = 0xce
*esi_6 - *edi_6
void* esi_7
void* edi_7

if (d)
    esi_7 = esi_6 - 1
    edi_7 = edi_6 - 1
else
    esi_7 = esi_6 + 1
    edi_7 = edi_6 + 1

__return_addr = __return_addr_1
*edi_7
*(esi_7 - 0x2fd507e6) = int.q(fconvert.t(*0x3dc61ece) / arg7)
*0xcbe18591
*edi_7
undefined
