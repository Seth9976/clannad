// 函数: sub_49df81
// 地址: 0x49df81
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1
undefined
