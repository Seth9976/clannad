// 函数: sub_46c151
// 地址: 0x46c151
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg5 - 0x763f1ad9)
void* const* var_4 = &__return_addr
*(arg3 + 0x595763f9)
void* var_4_1 = arg1
void* var_8 = arg3
int32_t var_c = arg2
int32_t ebx
int32_t var_10 = ebx
int32_t* var_14 = &var_10
int32_t var_18 = arg4
void* var_20 = arg5
*(arg2 + (arg5 << 2)) = rol.b(*(arg2 + (arg5 << 2)), 1)
ebx:1.b = 0xcf
bool p = unimplemented  {dec ebp}

if (p)
    *(arg1 + 0x53) += arg1:1.b
    *(arg5 + 0x47) -= arg2.b
    int32_t gsbase
    *(gsbase + arg3 - 0x4ae7c043)
    undefined

arg3:1.b = 0xca

if (arg4 - 1 s< 0 != add_overflow(arg4, 0xffffffff))
    undefined

jump(0x46c25a)
