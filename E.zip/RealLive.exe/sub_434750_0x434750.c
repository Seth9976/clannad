// 函数: sub_434750
// 地址: 0x434750
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t i
int32_t i_1 = i
*arg3
i:1.b = 0x43
int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __daa(arg1.b, eflags)
arg1.b = temp0
arg1.b &= *arg1
arg1[0x59] += arg1:1.b

while (i != 0)
    bool cond:0_1 = arg1 == *arg4
    arg4 += 4
    i -= 1
    
    if (not(cond:0_1))
        break

undefined
