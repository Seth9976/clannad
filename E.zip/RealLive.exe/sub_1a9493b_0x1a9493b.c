// 函数: sub_1a9493b
// 地址: 0x1a9493b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (data_1c09308 == 0)
    sub_1a94553(0xfffffffd)
    data_1c09308 = 1
