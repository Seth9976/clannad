// 函数: sub_4be594
// 地址: 0x4be594
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*arg2 += __return_addr.w:1.b
int32_t edx
edx:1.b = 0xca
void arg_4
__return_addr = &arg_4
*arg2
undefined
