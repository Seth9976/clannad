// 函数: sub_4a727b
// 地址: 0x4a727b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*0xb893ccb3
char entry_ebx
*0xb893ccb3 = entry_ebx
int16_t es
uint32_t var_8 = zx.d(es)
uint32_t var_c = zx.d(es)
int32_t eflags
int32_t eax
eax.b = __salc(eflags)
undefined
