// 函数: sub_43482a
// 地址: 0x43482a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg4 + arg3 - 0x7c) = arg2
undefined
