// 函数: sub_4347f2
// 地址: 0x4347f2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ebp
int16_t es
ebp, es = __les_gprz_memp(*(arg2 - 0x77))
int32_t var_4 = ebp
*arg3
void* var_8 = arg2
*0x62e90000
undefined
