// 函数: sub_44f481
// 地址: 0x44f481
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char temp0
char temp1
temp0, temp1, eflags_1 = __aaa(arg1.b, arg1:1.b, eflags)
arg1.b = temp0
arg1:1.b = temp1
trap(0x54)
