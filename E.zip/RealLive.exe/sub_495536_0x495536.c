// 函数: sub_495536
// 地址: 0x495536
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b ^= arg2:1.b
arg1:1.b = 0x9c
*arg3
void* ecx
ecx:1.b = 0xc5
void* entry_ebx
*(ecx + 1) = sbb.d(*(ecx + 1), entry_ebx, false)
*(arg1 - 0x13) -= 0x64
*(entry_ebx - 0x51) &= arg2.b
undefined
