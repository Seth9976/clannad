// 函数: sub_495792
// 地址: 0x495792
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0x7353a581) += (arg3 - 1):1.b
arg1.b -= 0x28
*(arg4 - 0x28990000)
return sub_4957fc(arg3 - 1, arg2.w) __tailcall
