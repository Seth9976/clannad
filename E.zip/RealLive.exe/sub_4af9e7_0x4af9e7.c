// 函数: sub_4af9e7
// 地址: 0x4af9e7
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__out_immb_oeax(0xe8, arg1, eflags)
arg3.b ^= *(arg1 + 0x4a)
arg1:1.b &= *(arg4 + 0x4dcfaf53)
return arg5 + fconvert.t(*(arg3 - 0x42e973a4))
