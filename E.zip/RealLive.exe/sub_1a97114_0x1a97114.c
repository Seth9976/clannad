// 函数: sub_1a97114
// 地址: 0x1a97114
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ecx
int32_t var_8 = ecx
int32_t var_c = ecx
void** esi = data_1bfc0d0
void* result

while (true)
    int32_t edx_1 = esi[4]
    int32_t ebx_1
    
    if (edx_1 == 0xffffffff)
        ebx_1 = arg1
    else
        void* edi_1 = esi[2]
        void* eax_6 = ((edi_1 - esi - 0x18) s>> 3 << 0xc) + edx_1
        void* var_8_1 = eax_6
        
        if (edi_1 u< &esi[0x806])
            while (true)
                int32_t ecx_2 = *edi_1
                ebx_1 = arg1
                
                if (ecx_2 s>= ebx_1 && *(edi_1 + 4) u> ebx_1)
                    result = sub_1a9731c(eax_6, ecx_2, ebx_1)
                    
                    if (result != 0)
                        break
                    
                    eax_6 = var_8_1
                    *(edi_1 + 4) = ebx_1
                
                edi_1 += 8
                eax_6 += 0x1000
                var_8_1 = eax_6
                
                if (edi_1 u>= &esi[0x806])
                    goto label_1a9718a
            
            goto label_1a971df
        
        ebx_1 = arg1
    label_1a9718a:
        int32_t eax_7 = esi[2]
        edi_1 = &esi[6]
        void* var_8_2 = esi[4]
        
        if (edi_1 u< eax_7)
            while (true)
                int32_t eax_8 = *edi_1
                
                if (eax_8 s>= ebx_1 && *(edi_1 + 4) u> ebx_1)
                    result = sub_1a9731c(var_8_2, eax_8, ebx_1)
                    
                    if (result != 0)
                        break
                    
                    *(edi_1 + 4) = ebx_1
                
                var_8_2 += 0x1000
                edi_1 += 8
                
                if (edi_1 u>= eax_7)
                    goto label_1a971d0
            
        label_1a971df:
            data_1bfc0d0 = esi
            *edi_1 -= ebx_1
            esi[2] = edi_1
            break
    
label_1a971d0:
    esi = *esi
    
    if (esi == data_1bfc0d0)
        void** edi_2 = &data_1bfa0b0
        int32_t i
        int32_t dwSize
        int32_t* ebx_2
        int32_t* lpAddress
        
        while (true)
            if (edi_2[4] == 0xffffffff || edi_2[3] == 0)
                edi_2 = *edi_2
                
                if (edi_2 == &data_1bfa0b0)
                    void** eax_17 = sub_1a96e1c()
                    
                    if (eax_17 != 0)
                        void** ecx_7 = eax_17[4]
                        ecx_7[2].b = ebx_1.b
                        data_1bfc0d0 = eax_17
                        *ecx_7 = ecx_7 + ebx_1 + 8
                        ecx_7[1] = 0xf0 - ebx_1
                        eax_17[6] -= zx.d(ebx_1.b)
                        return &ecx_7[0x40]
                else
                    continue
            else
                ebx_2 = edi_2[3]
                i = 0
                int32_t* eax_9 = ebx_2
                lpAddress = ((ebx_2 - edi_2 - 0x18) s>> 3 << 0xc) + edi_2[4]
                
                if (*ebx_2 == 0xffffffff)
                    while (i s< 0x10)
                        eax_9 = &eax_9[2]
                        i += 1
                        
                        if (*eax_9 != 0xffffffff)
                            break
                
                dwSize = i << 0xc
                
                if (VirtualAlloc(lpAddress, dwSize, MEM_COMMIT, PAGE_READWRITE) == lpAddress)
                    break
            
            return nullptr
        
        sub_1a917d0(lpAddress, dwSize.b, 0)
        int32_t* ecx_5 = ebx_2
        
        if (i s> 0)
            void* eax_12 = &lpAddress[1]
            int32_t i_2 = i
            int32_t i_1
            
            do
                *(eax_12 + 0xf4) = 0xff
                *(eax_12 - 4) = eax_12 + 4
                *eax_12 = 0xf0
                *ecx_5 = 0xf0
                ecx_5[1] = 0xf1
                eax_12 += 0x1000
                ecx_5 = &ecx_5[2]
                i_1 = i_2
                i_2 -= 1
            while (i_1 != 1)
        
        data_1bfc0d0 = edi_2
        bool c_1
        
        while (true)
            c_1 = ecx_5 u< &edi_2[0x806]
            
            if (not(c_1))
                break
            
            if (*ecx_5 == 0xffffffff)
                c_1 = ecx_5 u< &edi_2[0x806]
                break
            
            ecx_5 = &ecx_5[2]
        
        edi_2[3] = sbb.d(&edi_2[0x806], &edi_2[0x806], c_1) & ecx_5
        lpAddress[2].b = arg1.b
        edi_2[2] = ebx_2
        *ebx_2 -= arg1
        lpAddress[1] -= arg1
        result = &lpAddress[0x40]
        *lpAddress = lpAddress + arg1 + 8
        break

return result
