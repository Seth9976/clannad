// 函数: sub_4a663c
// 地址: 0x4a663c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
int16_t es
eax, es = __les_gprz_memp(*(arg1 * 5 + 0x64))
*arg2
char entry_ebx
*arg2 = entry_ebx
int32_t ecx
ecx:1.b = 0x23
bool c
bool p
bool a
bool z
bool s
eax:1.b = (s ? 1 : 0) << 7 | (z ? 1 : 0) << 6 | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (c ? 1 : 0)
unimplemented  {enter 0xad63, 0xcf}
int32_t var_4 = ecx
undefined
