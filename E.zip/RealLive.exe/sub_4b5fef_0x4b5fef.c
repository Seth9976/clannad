// 函数: sub_4b5fef
// 地址: 0x4b5fef
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
int16_t var_4 = ds
arg3 f- fconvert.t(*(arg2 + 0x58aabede))
undefined
