// 函数: sub_429dbb
// 地址: 0x429dbb
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
entry_ebx:1.b ^= 0xca

if (entry_ebx:1.b s<= 0)
    jump(0x429dc2)

int32_t eax_1
int32_t ecx_1
eax_1, ecx_1 = 0x4a0e4946()
*(arg1 - 0x4ee57fb0)
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
int32_t eax_3
int32_t ecx_3
eax_3, ecx_3 = 0x4a0e4958()
*(arg1 - 0x4ee57fb0)
int32_t eflags_2
int32_t eip_1
eip_1, eflags_2 = __into(eflags_1)
int32_t eax_5
int32_t ecx_5
eax_5, ecx_5 = 0x4a0e496a()
*(arg1 - 0x4ee57fb0)
int32_t eflags_3
int32_t eip_2
eip_2, eflags_3 = __into(eflags_2)
int32_t eax_7
int32_t ecx_7
eax_7, ecx_7 = 0x4a0e497c()
*(arg1 - 0x4ee57fb0)
int32_t eflags_4
int32_t eip_3
eip_3, eflags_4 = __into(eflags_3)
int32_t eax_9
int32_t ecx_9
eax_9, ecx_9 = 0x4a0e498e()
*(arg1 - 0x4ee57fb0)
int32_t eflags_5
int32_t eip_4
eip_4, eflags_5 = __into(eflags_4)
int32_t eax_11
int32_t ecx_11
eax_11, ecx_11 = 0x4a0e49a0()
*(arg1 - 0x4ee57fb0)
int32_t eflags_6
int32_t eip_5
eip_5, eflags_6 = __into(eflags_5)
int32_t eax_13
int32_t ecx_13
eax_13, ecx_13 = 0x4a0e49b2()
*(arg1 - 0x4ee57fb0)
int32_t eflags_7
int32_t eip_6
eip_6, eflags_7 = __into(eflags_6)
int32_t eax_15
int32_t ecx_15
eax_15, ecx_15 = 0x4a0e49c4()
*(arg1 - 0x4ee57fb0)
int32_t eflags_8
int32_t eip_7
eip_7, eflags_8 = __into(eflags_7)
int32_t eax_17
int32_t ecx_17
eax_17, ecx_17 = 0x4a0e49d6()
*(arg1 - 0x4ee57fb0)
int32_t eflags_9
int32_t eip_8
eip_8, eflags_9 = __into(eflags_8)
int32_t eax_19
int32_t ecx_19
void* edx_10
eax_19, edx_10, ecx_19 = 0x4a0e49e8()
*(arg1 + 0x3e1d8650)
*(arg1 - 0x52) -= ecx_19
int32_t var_c = entry_ebx
*(edx_10 + 0xf) = not.b(*(edx_10 + 0xf))
*arg1
undefined
