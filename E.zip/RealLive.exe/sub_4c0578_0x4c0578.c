// 函数: sub_4c0578
// 地址: 0x4c0578
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

__pmulhuw_mmxq_memq(arg8, *(arg3 - 0x12))
void* entry_ebx
void* var_8 = entry_ebx
*arg5
void* edi = arg5 + 4
int32_t ecx
ecx:1.b = 0x8a
char temp0_1 = arg1
arg1 = arg2.b
arg2.b = temp0_1
*((arg4 << 2) + 0x534616ca) += entry_ebx.b
__pmulhuw_mmxq_memq(arg9, *(entry_ebx + 0x4caf53e1))
ecx:1.b = 0x8c
char temp0_3 = arg1
arg1 = arg2.b
arg2.b = temp0_3
__pmulhuw_mmxq_memq(arg7, *(arg2 - 0x13))
void* var_d = entry_ebx
*edi
void* edi_1 = edi + 4
ecx:1.b = 0x8e
arg2.b = arg1
int32_t eflags
char temp0_6 = __in_al_immb(0x13, eflags)
ecx:1.b = 0xca
int16_t ss
uint32_t var_12 = zx.d(ss)
void* var_16 = edi_1
__pmulhuw_mmxq_memq(arg6, *(edi_1 + 0x4caf53e1))
ecx:1.b = 0x80
arg2.b = temp0_6
undefined
