// 函数: sub_418de5
// 地址: 0x418de5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ebx
ebx.b = arg3.b
int32_t var_4 = 0x3d
int32_t ecx
int16_t es
ecx, es = __les_gprz_memp(*(arg3 * 5))
int32_t var_8 = ebx
*arg4
undefined
