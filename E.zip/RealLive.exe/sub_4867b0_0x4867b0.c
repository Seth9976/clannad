// 函数: sub_4867b0
// 地址: 0x4867b0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4de67cad) = int.w(arg4)
trap(0x92)
