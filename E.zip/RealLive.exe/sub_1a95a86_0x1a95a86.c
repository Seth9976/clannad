// 函数: sub_1a95a86
// 地址: 0x1a95a86
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1a97834() + 8
