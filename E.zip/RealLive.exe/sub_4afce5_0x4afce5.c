// 函数: sub_4afce5
// 地址: 0x4afce5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg2:1.b u>>= arg1.b
int32_t var_4 = arg1
*arg3
trap(0x4f)
