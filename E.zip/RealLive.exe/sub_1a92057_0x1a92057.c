// 函数: sub_1a92057
// 地址: 0x1a92057
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(9)
