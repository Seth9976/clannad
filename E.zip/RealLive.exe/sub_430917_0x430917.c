// 函数: sub_430917
// 地址: 0x430917
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b -= 0x77
*(arg4 - 0x416ad5c5)
*(arg3 + 0x53ec34e6) += arg3.b
*arg4
int32_t edi = arg4 + 4
*(arg3 + 0xb978454) ^= arg3.b
int32_t eflags
char temp0 = __in_al_dx(arg2, eflags)
void* entry_ebx
void* var_8 = entry_ebx
*edi
int32_t* var_c = &var_8
*(arg1 - 0x2dd47960)
*(entry_ebx - 0x3a9a235c) += temp0 + 0x77
int32_t var_10 = edi + 4
undefined
