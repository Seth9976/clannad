// 函数: sub_477981
// 地址: 0x477981
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
int16_t var_4 = ds
int32_t var_6 = sx.d(arg1)
void* var_a = arg3
int32_t ebx
int32_t var_12 = ebx
int32_t* var_16 = &var_12
void* var_1e = arg4
*(arg4 + 0x4aaf3fd8) s>>= 1
*(arg3 - 0x1671f0fa)
trap(0x95)
