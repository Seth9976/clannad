// 函数: sub_4867d4
// 地址: 0x4867d4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4be67cad) = int.w(arg4)
undefined
