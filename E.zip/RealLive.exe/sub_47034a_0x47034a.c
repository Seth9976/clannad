// 函数: sub_47034a
// 地址: 0x47034a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void arg_16cabf31
*(&arg_16cabf31 + (edx << 3)) = int.q(arg5)
bool p

if (not(p))
    if (arg3 == 0)
        noreturn sub_47031d(arg1, arg4 + 1) __tailcall
    
    arg1.b = *(arg4 + 1)

int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __das(arg1.b, eflags)
arg1.b = temp0
int32_t eflags_2
char temp0_1
temp0_1, eflags_2 = __daa(arg1.b, eflags_1)
arg1.b = temp0_1
return arg1
