// 函数: sub_4bcb49
// 地址: 0x4bcb49
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg3[-0x4867e2b]
arg3[-0x4867e2b] = ror.d(arg3[-0x4867e2b], 0xc5)
bool c_1 = unimplemented  {ror dword [ecx-0x1219f8ac], 0xc5}
int32_t entry_ebx
int32_t temp1 = *(arg3 + entry_ebx)
*(arg3 + entry_ebx) = adc.d(temp1, arg4, c_1)
int32_t* var_8 = arg3
int32_t var_c = arg2
int32_t var_10 = entry_ebx
int32_t* var_14 = &var_10
int32_t var_18 = arg4
int32_t var_20 = arg5
int32_t var_24 = entry_ebx
arg1.b = adc.b(arg1.b, 0xa, 
    adc.d(temp1, arg4, c_1) u< temp1 || (c_1 && adc.d(temp1, arg4, c_1) == temp1))
arg1.b = *0x89c1844b
int16_t var_28 = &var_24
int32_t eflags
__out_immb_al(0xef, arg1.b, eflags)
__outsd(arg2.w, *0x5bf83d9c, 0x5bf83d9c, eflags)
int32_t var_2a = arg4
int32_t var_2e = arg5
*arg5
undefined
