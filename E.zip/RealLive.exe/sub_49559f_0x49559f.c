// 函数: sub_49559f
// 地址: 0x49559f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1
undefined
