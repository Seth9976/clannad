// 函数: sub_4a46bf
// 地址: 0x4a46bf
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* const* var_4_1 = &__return_addr
int32_t eflags
int32_t eflags_1
char temp0
char temp1
temp0, temp1, eflags_1 = __aas(arg1.b, arg1:1.b, eflags)
arg1.b = temp0
arg1:1.b = temp1
int32_t edx_1
int32_t entry_ebx
edx_1:1.b = (arg2 - 2):1.b + entry_ebx.b
*arg4 - *arg5
char* var_4 = arg1
int32_t eflags_2
int32_t eip
eip, eflags_2 = __into(eflags_1)
int16_t ds
int16_t var_6 = ds
__int1()
void* result = __in_oeax_immb(0xcf, eflags_2)

if (entry_ebx + 0x37d8078c s>= 0xffffffff)
    return result

*(var_4_1 - 0x6e) += arg3:1.b
bool c = *0xd02a4409 u< *arg1
char* var_8 = arg1
result.b = 0x8d
*(result - 0x9e131ea)
char* ebx
ebx:1.b = arg1.b
void* const* ebp
ebp.w = adc.w(var_4_1.w, &var_8:2, c)
undefined
