// 函数: sub_4936e6
// 地址: 0x4936e6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 - 0x4b5a8499)
undefined
