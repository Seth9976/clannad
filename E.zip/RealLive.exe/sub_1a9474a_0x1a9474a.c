// 函数: sub_1a9474a
// 地址: 0x1a9474a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (arg1 == 0x3a4)
    return 0x411

if (arg1 == 0x3a8)
    return 0x804

if (arg1 == 0x3b5)
    return 0x412

if (arg1 == 0x3b6)
    return 0x404

return 0
