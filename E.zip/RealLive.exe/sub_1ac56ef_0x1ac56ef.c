// 函数: sub_1ac56ef
// 地址: 0x1ac56ef
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1ac54a8(0x1c0724c, 0x1ac467e)
