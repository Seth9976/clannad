// 函数: sub_4a44e4
// 地址: 0x4a44e4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ecx
ecx.b = 0xda
