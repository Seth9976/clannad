// 函数: sub_1a9feac
// 地址: 0x1a9feac
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t* esi = data_1c076c0
uint8_t* i = *esi

while (i != 0)
    if (sub_1a9f073(arg1, i, arg2) == 0)
        char* eax_1
        eax_1.b = *(*esi + arg2)
        
        if (eax_1.b == 0x3d || eax_1.b == 0)
            return (esi - data_1c076c0) s>> 2
    
    i = esi[1]
    esi = &esi[1]

return neg.d((esi - data_1c076c0) s>> 2)
