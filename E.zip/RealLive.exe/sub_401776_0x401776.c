// 函数: sub_401776
// 地址: 0x401776
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
eax.b = *arg4
int16_t ds
uint32_t var_8 = zx.d(ds)
arg5 f- arg6
int32_t eflags
__out_dx_oeax(arg2, eax | 0xc44201d8, eflags)
undefined
