// 函数: sub_430901
// 地址: 0x430901
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
int32_t var_4 = entry_ebx
*arg4
*arg1 = int.d(arg5)
int32_t var_6d[0x19]
var_6d[arg1] = arg2
int32_t ebx = entry_ebx ^ *(arg3 + 1)
int32_t eflags
int32_t eax
eax.b = __in_al_dx(arg2.w, eflags)
int32_t var_8 = ebx
*(arg4 + 4)
undefined
