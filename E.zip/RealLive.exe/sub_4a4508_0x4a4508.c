// 函数: sub_4a4508
// 地址: 0x4a4508
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
char temp0_1 = __in_al_dx(arg2, eflags)
void* entry_ebx
char temp0 = *(entry_ebx - 0x39)
*(entry_ebx - 0x39) u>>= 1
char result = adc.b(temp0_1, *(arg3 - 0x25f8f02c), (temp0 & 1) != 0)
*arg1 = arg1
return result
