// 函数: sub_444101
// 地址: 0x444101
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* const* var_4 = &__return_addr
*(arg4 - 0x41158453)
arg1.b = adc.b(arg1.b, 0xc2, false)
arg1.b = 0x4d
arg1.b = 0xd
int32_t eflags
void* entry_ebx

if ((*(entry_ebx + 0x1e) & arg3.b) s>= 0)
    int16_t ds
    uint32_t var_8_1 = zx.d(ds)
    __out_dx_oeax(arg2, arg1, eflags)
    *(entry_ebx - 1)
    *(arg1 + (entry_ebx << 3) - 0x4fe38cb4) &= 0x4d
    *(arg4 - 0x15866a8a) &= arg2.b

arg1.b = __in_al_dx(arg2, eflags)
arg2.b |= *(arg1 + 0x7f9dbe8c)
undefined
