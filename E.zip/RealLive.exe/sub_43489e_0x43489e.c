// 函数: sub_43489e
// 地址: 0x43489e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp0 = *(arg4 - 0x15)
*(arg4 - 0x15) += arg2.b
*(arg3 - 0x657c377) -= arg2:1.b
int32_t eax
int32_t entry_ebx
eax.b = *(entry_ebx + sbb.d(arg1, 0xd3a2dabb, temp0 + arg2.b u< temp0))
undefined
