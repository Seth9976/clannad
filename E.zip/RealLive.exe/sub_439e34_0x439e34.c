// 函数: sub_439e34
// 地址: 0x439e34
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp0 = *(arg2 + 0x30)
bool c
*(arg2 + 0x30) = adc.b(temp0, 0xce, c)
arg1.b =
    sbb.b(arg1.b, 0x9d, adc.b(temp0, 0xce, c) u< temp0 || (c && adc.b(temp0, 0xce, c) == temp0))
int32_t temp1 = *(arg3 + arg2 + 0x30)
*(arg3 + arg2 + 0x30) = rol.d(*(arg3 + arg2 + 0x30), 1)
bool o = unimplemented  {rol dword [ecx+edx+0x30], 0x1}

if (rol.d(temp1, 1) s< 0 == o)
    void* ebp
    return sub_439e42(ebp, arg5) __tailcall

*arg5 = *arg4
int16_t ds
uint32_t var_7 = zx.d(ds)
arg3:1.b = 0xa0
int32_t ebx
ebx:1.b = 0x33
*(&var_7 + (&arg5[1] << 1))
int16_t eax
eax:1.b = (arg1 - 1):1.b u>> 0x53
undefined
