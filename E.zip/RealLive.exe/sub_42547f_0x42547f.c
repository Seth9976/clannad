// 函数: sub_42547f
// 地址: 0x42547f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
jump(entry_ebx)
