// 函数: sub_4a723a
// 地址: 0x4a723a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 += (arg2 - 1):1.b
int32_t ebx
ebx:1.b = 0xa6
int32_t var_4 = ebx
*arg3
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*(arg3 - 0x4ce77daa)
breakpoint
