// 函数: sub_4955b4
// 地址: 0x4955b4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

long double result = arg4 / fconvert.t(*(arg2 + 0x70))
*(arg2 + 0x569583ed) += arg3
return result
