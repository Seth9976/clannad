// 函数: sub_1a91f8b
// 地址: 0x1a91f8b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(9)
