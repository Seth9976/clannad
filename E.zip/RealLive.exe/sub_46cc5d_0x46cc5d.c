// 函数: sub_46cc5d
// 地址: 0x46cc5d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 - 0x32) = int.d(arg2)
undefined
