// 函数: sub_4867f8
// 地址: 0x4867f8
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4de67cad) = int.w(arg4)
trap(0x92)
