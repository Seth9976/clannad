// 函数: sub_48675b
// 地址: 0x48675b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ss
*arg4 = ss
*(arg1 - 0x28) |= arg3:1.b
int32_t eflags
arg1.b = __in_al_immb(0x5b, eflags)
*arg4 - *arg5
void* esi = &arg4[2]
*0x8b69d92 = 0x168c5c81
*(arg1 - 0x28) |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi - *(arg5 + 4)
unimplemented  {enter 0x554a, 0xc0}
*(__return_addr - 4) = __return_addr
*(esi + 4)
undefined
