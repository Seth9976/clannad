// 函数: sub_4b0f25
// 地址: 0x4b0f25
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t entry_ebx
bool c
arg2:1.b = adc.b(arg2:1.b, entry_ebx:1.b, c)
undefined
