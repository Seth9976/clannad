// 函数: sub_439e42
// 地址: 0x439e42
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 + 0x43f4f4e4) -= 1
*arg2
undefined
