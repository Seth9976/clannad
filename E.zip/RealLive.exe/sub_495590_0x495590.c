// 函数: sub_495590
// 地址: 0x495590
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

trap(0xd)
