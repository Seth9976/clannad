// 函数: sub_4c4091
// 地址: 0x4c4091
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* const __return_addr_1 = __return_addr
int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __daa((arg1 - 1).b, eflags)
uint64_t* eax
eax.b = temp0
arg2.b = 0x75
bool c
*(eax - 0xbd3743d) = adc.b(*(eax - 0xbd3743d), 0xe0, c)
*arg6
int16_t __return_addr_2
__return_addr = zx.d(__return_addr_2)
__return_addr_1.b ^= eax.b

if (__return_addr_1.b != 0 && arg3 == 1)
    undefined

eax.b = __in_al_immb(0xfa, eflags_1)
void* const __return_addr_5 = __return_addr_1
*arg6
int32_t edi = arg6 + 4
char temp0_2 = eax.b
eax.b = 0x75
arg2.b = temp0_2
__out_immb_oeax(0x1f, eax, eflags_1)
int16_t ss
uint32_t var_9 = zx.d(ss)
int32_t var_d = arg4 - 1
__pmulhuw_mmxq_memq(arg7, *(arg2 + 0x4caf53ed))
eax.b = arg2.b
arg2.b = 0x75
*(arg5 + 1)
uint32_t ecx_1
ecx_1:1.b = 0xca
uint32_t var_11 = zx.d(ss)
int32_t var_15 = edi
_mm_mulhi_pu16(arg8, arg10)
void* const __return_addr_4 = __return_addr_1
*edi
void var_1a
void* const* esp = &var_1a
ecx_1:1.b = 0x80
char temp0_5 = eax.b
eax.b = 0x75
arg2.b = temp0_5

if (&var_1a s< 0)
    uint32_t var_1e_1 = zx.d(ss)
    __pmulhuw_mmxq_memq(arg9, *__return_addr_1)
    void* const __return_addr_3 = __return_addr_1
    *(edi + 4)
    ecx_1:1.b = 0x82
    esp = &__return_addr_4

__out_immb_al(0xee, 0x75, eflags_1)
int16_t edx
int16_t ds
edx, ds = __lds_gprz_memp(*eax)
void* const eax_1 = *esp
__verr_memw(*(eax_1 + 0x5b))
__return_addr_1:1.b = 0x4c
ecx_1:1.b = 0xd9
char temp0_7 = eax_1.b
eax_1.b = edx.b
edx.b = temp0_7
eax_1.b += 0x1e
ecx_1:1.b = 0xca
*esp = zx.d(ss)
edx:1.b += *(__return_addr_1 * 2 + 0x39)
edx.b = *(eax_1 - 0x51)
undefined
