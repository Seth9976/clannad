// 函数: sub_4a6660
// 地址: 0x4a6660
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t entry_ebx
entry_ebx:1.b ^= entry_ebx.b
*(arg1 - 0x6a354e95) = adc.d(*(arg1 - 0x6a354e95), arg2, false)
undefined
