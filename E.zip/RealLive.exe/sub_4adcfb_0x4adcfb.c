// 函数: sub_4adcfb
// 地址: 0x4adcfb
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

undefined
