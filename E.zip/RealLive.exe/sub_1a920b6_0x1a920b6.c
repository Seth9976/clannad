// 函数: sub_1a920b6
// 地址: 0x1a920b6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(9)
