// 函数: sub_4867de
// 地址: 0x4867de
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 + 2)
void* const* eax
int32_t entry_ebx
eax.b = *(entry_ebx + &__return_addr)
eax.b += 4
int32_t eflags
char temp0
char temp1
temp0, temp1, eflags = __aam_immb(0xe8, eax.b)
eax.b = temp0
eax:1.b = temp1
*arg1 = 0xd7670707
*0xd7670707 = eax
undefined
