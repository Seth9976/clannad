// 函数: sub_4be591
// 地址: 0x4be591
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
int32_t var_4 = eax
*arg1
undefined
