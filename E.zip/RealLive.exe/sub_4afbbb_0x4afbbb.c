// 函数: sub_4afbbb
// 地址: 0x4afbbb
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
uint16_t eax = __in_oeax_immb(0xea, eflags)
*(arg2 + 0x49) ^= arg1.b
void* edx
edx.b = (arg2 - 1).b + arg1.b
eax:1.b &= *(arg3 + 0x4dcfaf53)
*(arg1 - 0x4ee57fac)
undefined
