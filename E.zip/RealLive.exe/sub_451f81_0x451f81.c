// 函数: sub_451f81
// 地址: 0x451f81
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
*(entry_ebx * 3)
*arg4
undefined
