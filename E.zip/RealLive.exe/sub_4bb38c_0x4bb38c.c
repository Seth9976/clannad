// 函数: sub_4bb38c
// 地址: 0x4bb38c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t cs
*(cs + arg4 + 0x60) s>>= 0x53
arg1.b -= 0x73
void* entry_ebx
*(entry_ebx - 0x1c000136)
arg3.b &= *(entry_ebx - 0x1c000136)
arg1.b = adc.b(arg1.b, 0xfc, false)
*0x489bb23 = &__return_addr
void* const edi = 0x489bb22
*(edi + 0x1e845489)
arg3:1.b = 0xd
int32_t esi = *arg1
*(edi + 0x60) s>>= 0xd0
int32_t eflags
void* const* eax
eax.b = __in_al_dx(arg2, eflags)
*arg1 = entry_ebx
*edi
eax[5].b |= arg3.b
char eax_3 = (adc.d(eax - 1 - *(esi + entry_ebx + 0x3595cab5), 0xecafa1f4, 
    eax - 1 u< *(esi + entry_ebx + 0x3595cab5))).b
*(arg1 - 4) = zx.d(cs)
entry_ebx.b ^= eax_3
entry_ebx.b += *(arg3 + 0x48)
undefined
