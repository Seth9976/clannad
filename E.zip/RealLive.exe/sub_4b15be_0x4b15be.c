// 函数: sub_4b15be
// 地址: 0x4b15be
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* edx_1 = *(arg3 - 0x7d)
bool c
*(edx_1 + 0x7b992cd) = sbb.d(*(edx_1 + 0x7b992cd), arg2, c)
int32_t entry_ebx
arg1.b = *(entry_ebx + arg1)
arg1.b += 5
arg1.w += 1
int32_t eflags
__out_immb_oeax(0x46, arg1, eflags)
arg1.b = __in_al_immb(0xcf, eflags)
trap(0xc2)
