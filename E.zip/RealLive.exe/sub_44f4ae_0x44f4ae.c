// 函数: sub_44f4ae
// 地址: 0x44f4ae
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx + 0x4e53a820) += arg1:1.b
int32_t eflags
int32_t eflags_1
char temp0
char temp1
temp0, temp1, eflags_1 = __aas(arg1.b, arg1:1.b, eflags)
arg1.b = temp0
arg1:1.b = temp1
*__return_addr = *arg2
void* esi_1 = arg2 + 1
*esi_1 = rrc.b(*esi_1, 0xb2, false)
*(arg5 + 0x2a78cfeb) <<= 0xcd
void arg_21
arg6 = &arg_21
__int1()
undefined
