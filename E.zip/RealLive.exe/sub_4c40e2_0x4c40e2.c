// 函数: sub_4c40e2
// 地址: 0x4c40e2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

__pmulhuw_mmxq_memq(arg3, *(arg1 + 0x4caf53ee))
int32_t ecx
ecx:1.b = 0x8a
arg1.b = arg2
undefined
