// 函数: sub_44f41e
// 地址: 0x44f41e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char entry_ebx
*0x2b53a83e += entry_ebx
*arg1 &= arg1
*arg2
*(arg4 - 0x2fdb1138) s>>= 1
*(arg3 + 0x3748cfeb)
trap(0x54)
