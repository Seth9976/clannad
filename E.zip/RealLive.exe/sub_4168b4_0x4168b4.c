// 函数: sub_4168b4
// 地址: 0x4168b4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0x23) = arg2
int32_t eflags
int32_t eax
eax.b = __in_al_immb(0x49, eflags)
int32_t eax_1
void* ecx
int32_t edx
eax_1, edx, ecx = 0x60428dfb()
int32_t esi = __outsb(edx.w, *arg4, arg4, eflags)
int32_t var_1
*(var_1 - 4) = arg3
*esi
*0xd171840f
*0xd171840f s>>= 0xec
bool c = unimplemented  {sar byte [0xffffffffd171840f], 0xec}
void* entry_ebx
*(var_1 - 8) = entry_ebx
*arg3
entry_ebx.b = sbb.b(entry_ebx.b, *(entry_ebx - 0x7a), c)
*(entry_ebx - 0xc354ae1)
*(entry_ebx - 0xc354ae1) = rol.b(*(entry_ebx - 0xc354ae1), 1)
bool c_1 = unimplemented  {rol byte [ebx-0xc354ae1], 0x1}
*(ecx - 0x7d) = sbb.d(*(ecx - 0x7d), 0x6f, c_1)
bool c_2 = unimplemented  {sbb dword [ecx-0x7d], 0x6f}
*arg3 = &arg3[1]
*(entry_ebx - 0x51) = adc.d(*(entry_ebx - 0x51), eax_1, c_2)
undefined
