// 函数: sub_4c132e
// 地址: 0x4c132e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0x4453a0de) += arg3:1.b
*arg3 = rol.b(*arg3, 0xd8)
*(arg4 - 0x41) u>>= 0xa3
undefined
