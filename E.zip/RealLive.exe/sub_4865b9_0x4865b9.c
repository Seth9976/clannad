// 函数: sub_4865b9
// 地址: 0x4865b9
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg4
char** edi = arg4 + 1
char* eax

if (arg1 == 0x33c90628 || arg1 u>= 0x33c90628)
    int32_t eflags_11
    char temp0_12
    char temp1_1
    temp0_12, temp1_1, eflags_11 = __aam_immb(0xe8, (arg1 - 0x33c90628).b)
    eax.b = temp0_12
    eax:1.b = temp1_1
    char** var_8_1 = edi
    *edi = eax
    undefined

bool c0
bool c1
bool c2
bool c3
*(arg3 - 0x2fd79ddc) =
    (c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe
char temp2 = *(arg1 - 0x33c90628)
eax.b = divu.dp.b((arg1 - 0x33c90628).w, temp2)
eax:1.b = modu.dp.b((arg1 - 0x33c90628).w, temp2)
int32_t eflags
__out_immb_oeax(0xcf, eax, eflags)
void* entry_ebx
entry_ebx:1.b = *(entry_ebx + 0x1e8454c1)
int32_t ecx
ecx.b = 0xce
int32_t eax_2
int32_t ecx_2
int16_t ds
eax_2, ecx_2 = 0x4a141136(zx.d(ds))
*(arg2 - 0x4ee57fb0)
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
int32_t eax_4
int32_t ecx_4
eax_4, ecx_4 = 0x4a141148()
*(arg2 - 0x4ee57fb0)
int32_t eflags_2
int32_t eip_1
eip_1, eflags_2 = __into(eflags_1)
int32_t eax_6
int32_t ecx_6
eax_6, ecx_6 = 0x4a14115a()
*(arg2 - 0x4ee57fb0)
int32_t eflags_3
int32_t eip_2
eip_2, eflags_3 = __into(eflags_2)
int32_t eax_8
int32_t ecx_8
eax_8, ecx_8 = 0x4a14116c()
*(arg2 - 0x4ee57fb0)
int32_t eflags_4
int32_t eip_3
eip_3, eflags_4 = __into(eflags_3)
int32_t eax_10
int32_t ecx_10
eax_10, ecx_10 = 0x4a14117e()
*(arg2 - 0x48e37ab0)
int32_t eflags_5
int32_t eip_4
eip_4, eflags_5 = __into(eflags_4)
int32_t eax_12
int32_t ecx_12
eax_12, ecx_12 = 0x4a141190()
*(arg2 - 0x4ee57fb0)
int32_t eflags_6
int32_t eip_5
eip_5, eflags_6 = __into(eflags_5)
int32_t eax_14
int32_t ecx_14
eax_14, ecx_14 = 0x4a1411a2()
*(arg2 - 0x4ee57fb0)
int32_t eflags_7
int32_t eip_6
eip_6, eflags_7 = __into(eflags_6)
int32_t eax_16
int32_t ecx_16
eax_16, ecx_16 = 0x4a1411b4()
*(arg2 - 0x4ee57fb0)
int32_t eflags_8
int32_t eip_7
eip_7, eflags_8 = __into(eflags_7)
int32_t eax_18
int32_t ecx_18
eax_18, ecx_18 = 0x4a1411c6()
*(arg2 - 0x4ee57fb0)
int32_t eflags_9
int32_t eip_8
eip_8, eflags_9 = __into(eflags_8)
int32_t eax_20
int32_t ecx_20
eax_20, ecx_20 = 0x4a1411d8()
*(arg2 - 0x4ee57fb0)
int32_t eflags_10
int32_t eip_9
eip_9, eflags_10 = __into(eflags_9)
char* eax_21 = ecx_20
__out_dx_oeax(0x404, eax_21, eflags_10)
char* var_8 = eax_21
*edi = eax_21
undefined
