// 函数: sub_49524e
// 地址: 0x49524e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx - 0x52) -= arg2
undefined
