// 函数: sub_4438ef
// 地址: 0x4438ef
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 0x265f7cdc) = fconvert.s(arg6)
void* ebx
ebx.b = (arg3 + 1).b
void arg_20
*(&arg_20 + (arg1 << 2)) = arg5
bool c
int32_t ebp = sbb.d(arg4, *(ebx + 0x41), c)
*(arg1 - 0x291c0067) += 1
arg1.b -= 0x85
int16_t edx_1 = (*__return_addr).w
ebx.b <<= 0xad
int32_t eflags
__out_immb_al(2, arg1.b, eflags)

if (ebx.b != 0)
    int32_t eax_5 = __in_oeax_dx(edx_1 - 1, eflags)
    *(eax_5 - 4) = ebp
    *0x504274e4 u>>= 1
    *0x2c91db7d = fconvert.s(arg7)
    *(eax_5 - 4)
    void* ebx_1
    ebx_1.b = (arg3 + 1).b + 1
    *(eax_5 - 2 + ((__return_addr + 4) << 2) + 0x1e) = arg5
    *(eax_5 - 2)
    *(ebx_1 + 0x41)
    *(__return_addr - 0x291c0063) += 1
    undefined

*__return_addr = arg1
*(arg1 - 4) = __return_addr
__in_oeax_dx(edx_1, eflags)
*(ebx - 0x63) u>>= 1
int32_t eax_2 = __in_oeax_dx(0x5862, eflags)
*(eax_2 - 4) = ebp

if (arg3 != 0)
    __int1()
    return sub_4438eb() __tailcall

*(eax_2 - 8) = arg3
*(eax_2 - 8)
__int1()
*(eax_2 - 8) = 0x50427547
undefined
