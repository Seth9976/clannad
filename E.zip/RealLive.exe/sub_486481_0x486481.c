// 函数: sub_486481
// 地址: 0x486481
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
int32_t temp1 = *(entry_ebx - 0x3d)
bool c
int32_t esi_2 = adc.d(arg2, temp1, c)
*(arg1 - 0x44) += 1
arg3 f- fconvert.t(*(esi_2 - 0x35))
*(arg1 - 0x77) = sbb.b(*(arg1 - 0x77), 0x10, 
    adc.d(arg2, temp1, c) u< arg2 || (c && adc.d(arg2, temp1, c) == arg2))
bool c_1 = unimplemented  {sbb byte [eax-0x77], 0x10}
int32_t esi = adc.d(esi_2, *(entry_ebx - 0x3d), c_1)
*(arg1 - 0x44) += 1
arg4 f- fconvert.t(*(esi - 0x35))
char eax
char ecx
int32_t edx_1
eax, edx_1, ecx = 0xb85af3ea()
*0xb0cfe70f = eax
undefined
