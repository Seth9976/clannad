// 函数: sub_4b4c04
// 地址: 0x4b4c04
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg7 f- arg8
*arg6
*(arg4 + 0x4bfee708)
*(arg5 - 0x6e) += arg2:1.b
*arg5 - *arg6
*(arg4 + 0x1743d805)
undefined
