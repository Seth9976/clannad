// 函数: sub_401f37
// 地址: 0x401f37
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx - 0x4fe47eaf) = int.q(arg1)
undefined
