// 函数: sub_4954e8
// 地址: 0x4954e8
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx - 0x52) -= arg2
undefined
