// 函数: sub_1a942c7
// 地址: 0x1a942c7
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

uint32_t dwExceptionCode
__builtin_memcpy(&dwExceptionCode, 0x1ad4578, 0x20)
int32_t var_c = arg1
int32_t var_8 = arg2
uint32_t dwExceptionFlags
uint32_t nNumberOfArguments
uint32_t arguments
RaiseException(dwExceptionCode, dwExceptionFlags, nNumberOfArguments, &arguments)
noreturn
