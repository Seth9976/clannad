// 函数: sub_4be5ca
// 地址: 0x4be5ca
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*(arg3 + 0x3d95caa0) += arg2.b
uint16_t* esi = __outsd(arg2, *arg4, arg4, eflags_1)
void arg_8
arg6 = &arg_8
__outsb(arg2, *esi, esi, eflags_1)
*arg5
undefined
