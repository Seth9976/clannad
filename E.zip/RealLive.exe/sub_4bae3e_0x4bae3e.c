// 函数: sub_4bae3e
// 地址: 0x4bae3e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
char entry_ebx
arg1.b &= entry_ebx
*(arg4 + 0x3d95cabf) += arg1.b
__return_addr = arg1
__outsd(arg2, *arg3, arg3, eflags_1)
int16_t var_4 = &__return_addr
int32_t eax
int32_t var_6 = eax
*arg4
undefined
