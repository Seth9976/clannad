// 函数: sub_4c4821
// 地址: 0x4c4821
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg4 = rrc.d(*arg4, 0xd0, c)
int16_t cs
uint32_t var_2 = zx.d(cs)
*(arg3 + 0x64)
undefined
