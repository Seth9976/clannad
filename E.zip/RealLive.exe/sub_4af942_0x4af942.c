// 函数: sub_4af942
// 地址: 0x4af942
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 0x42e973b0)
undefined
