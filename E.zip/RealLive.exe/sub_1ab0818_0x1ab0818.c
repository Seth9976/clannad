// 函数: sub_1ab0818
// 地址: 0x1ab0818
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t result = *(sub_1ac59a5() + 4)

if (result != 0)
    return result

return *(sub_1ac597f() + 4)
