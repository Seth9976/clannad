// 函数: sub_4957fc
// 地址: 0x4957fc
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eax
eax.b = __salc(eflags)
__in_oeax_dx(arg2, eflags)
char temp0 = *0xc853a583
*0xc853a583 += arg2:1.b
bool p = unimplemented  {add byte [0xffffffffc853a583], dh}
bool a = unimplemented  {add byte [0xffffffffc853a583], dh}
bool d
int32_t var_4 = (add_overflow(temp0, arg2:1.b) ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa
    | (temp0 + arg2:1.b s< 0 ? 1 : 0) << 7 | (temp0 == neg.b(arg2:1.b) ? 1 : 0) << 6
    | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (temp0 + arg2:1.b u< temp0 ? 1 : 0)
undefined
