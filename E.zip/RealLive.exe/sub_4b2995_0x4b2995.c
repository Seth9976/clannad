// 函数: sub_4b2995
// 地址: 0x4b2995
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char temp0_1
char temp1
temp0_1, temp1, eflags_1 = __aaa(arg1.b, arg1:1.b, eflags)
arg1.b = temp0_1
arg1:1.b = temp1
arg2.b -= 1
int32_t ecx
return sub_4b29f4(arg3, arg2, ecx, arg1, 0xd7670000) __tailcall
