// 函数: sub_4c1885
// 地址: 0x4c1885
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__out_dx_al(arg2, arg1, eflags)
int32_t* eax
int32_t* ecx
char* edx
eax, edx, ecx = 0xac61b350(arg3)
char temp1 = eax.b
eax.b -= 0xb
int32_t* var_8 = ecx
char temp0 = *edx
*edx = ecx.b
ecx.b = temp0
void* entry_ebx
ecx:1.b = entry_ebx.b
eax.b = adc.b(eax.b, 0x9a, temp1 u< 0xb)
*eax |= eax
*(entry_ebx - 0x281c7f68) += eax.b
edx.b ^= entry_ebx:1.b
int32_t eflags_1
bool c_2

while (true)
    long double x87_r0 = arg6 * fconvert.t(*edx)
    eax.b = *arg5
    void* esi = &arg5[1]
    char temp0_1
    char temp1_1
    temp0_1, temp1_1, eflags_1 = __aad_immb(0x11, eax.b, eax:1.b)
    eax.b = temp0_1
    eax:1.b = temp1_1
    *(arg4 - 1 + (edx << 2) - 0x42) ^= edx
    *(entry_ebx - 0x281c7d68) += eax.b
    bool c_1 = ecx.b u< entry_ebx:1.b
    arg4 -= 2
    arg6 = x87_r0 * fconvert.t(*edx)
    eax.b = *esi
    arg5 = esi + 1
    eax.b = *(entry_ebx + eax)
    int32_t temp2_1 = *ecx
    *ecx = adc.d(temp2_1, arg5, c_1)
    c_2 = adc.d(temp2_1, arg5, c_1) u< temp2_1 || (c_1 && adc.d(temp2_1, arg5, c_1) == temp2_1)
    
    if (ecx != 0)
        break
    
    *(eax + 0x32d7e37f) = sbb.d(*(eax + 0x32d7e37f), 0xffffffd7, c_2)

eax.b = __salc(eflags_1)
eax.b = *(entry_ebx + eax)

while (true)
    arg4 -= 1
    arg6 = arg6 * fconvert.t(*edx)
    eax.b = *arg5
    *ecx = rlc.d(*ecx, 1, c_2)
    *(edx - 0x7cff4173) ^= &arg5[0x84988300]
    char temp0_3 = entry_ebx.b
    entry_ebx.b = sx.d(eax.w):1.b
    eax:1.b = temp0_3
    eax.b = *(entry_ebx + eax)
    unimplemented  {enter 0x4dd7, 0xd8}
    *(entry_ebx + (edx << 3) - 0x726bceef)
    ecx:1.b |= *(entry_ebx + (edx << 3) - 0x726bceef)
    arg5 = 0x88988300
    
    if (ecx != 0)
        break
    
    eax[-0xa4a071f] = sbb.d(eax[-0xa4a071f], 0xffffffd7, false)
    c_2 = unimplemented  {sbb dword [eax-0x29281c7c], 0xffffffd7}

__cli(eflags_1)
eax.b = *(entry_ebx + eax)
eax.b = *0x88988300
void* const esi_2 = 0x88988301
*ecx = fconvert.d(arg6 * fconvert.t(*edx))
*(esi_2 - 0x7cff4173) ^= eax
int32_t eax_1 = sx.d(eax.w)
entry_ebx.b = *(eax_1 + 0x16372c5a)
eax_1.b = *(entry_ebx + eax_1)
char temp6 = eax_1.b
eax_1.b |= 0x6a
bool p = unimplemented  {or al, 0x6a}
bool a = undefined
bool d
int32_t var_c = (d ? 1 : 0) << 0xa | ((temp6 | 0x6a) s< 0 ? 1 : 0) << 7
    | ((temp6 | 0x6a) == 0 ? 1 : 0) << 6 | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2
int16_t ds
uint32_t var_10 = zx.d(ds)
ecx:1.b = 0x41
*(edx + 0x11f06818) = rrc.d(*(edx + 0x11f06818), 0x93, false)
void* var_14 = entry_ebx
undefined
