// 函数: sub_4af9d0
// 地址: 0x4af9d0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char* entry_ebx
entry_ebx:1.b |= *entry_ebx
long double x87_r0 = arg4 - fconvert.t(*(arg1 - 0x60))
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
int16_t ds
uint32_t var_2 = zx.d(ds)
__out_immb_al(0x3f, arg1.b, eflags_1)
*(arg2 - 0x2fd50a69) = int.q(x87_r0)
int32_t eflags_2
char temp0
char temp1
temp0, temp1, eflags_2 = __aaa(arg1.b, arg1:1.b, eflags_1)
arg1.b = temp0
arg1:1.b = temp1
*arg2 - *arg3
int32_t edx
int32_t var_6 = edx
return __in_oeax_immb(0xcf, eflags_2)
