// 函数: sub_495816
// 地址: 0x495816
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 0x4ce77eb1) = int.w(arg3)
undefined
