// 函数: sub_1a983ac
// 地址: 0x1a983ac
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(9)
