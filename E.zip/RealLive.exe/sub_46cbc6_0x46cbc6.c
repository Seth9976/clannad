// 函数: sub_46cbc6
// 地址: 0x46cbc6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char entry_ebx
*(arg2 + 0xb0e1053) = adc.d(*(arg2 + 0xb0e1053), arg3, entry_ebx + arg2.b u< entry_ebx)
return arg5 + fconvert.t(*(arg2 - 0x6b))
