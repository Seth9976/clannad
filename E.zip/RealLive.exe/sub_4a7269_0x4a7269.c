// 函数: sub_4a7269
// 地址: 0x4a7269
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg1 = sbb.b(*arg1, 0xb3, c)
breakpoint
