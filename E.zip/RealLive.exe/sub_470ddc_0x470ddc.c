// 函数: sub_470ddc
// 地址: 0x470ddc
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eax
eax.b = __in_al_dx(arg2, eflags)
*(arg1 + 0x3b) = rlc.b(*(arg1 + 0x3b), arg1.b, false)
*(arg1 + 0x779b8b0a)
undefined
