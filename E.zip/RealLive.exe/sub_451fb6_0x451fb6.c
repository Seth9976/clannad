// 函数: sub_451fb6
// 地址: 0x451fb6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg3 |= arg1.b
int32_t eflags
__outsd(arg2.w, *arg5, arg5, eflags)
void* var_4 = arg4
int32_t var_8 = 0xc6cfaf53
int16_t gs
*(arg4 + 0x7c9dd25c) = gs
void* eax = arg1 ^ 0x3b04cc1e
*(arg3 - 0x2eb869d9)
*(eax + 0x3e72f154)
*0x40eafffc = eax
*arg6
undefined
