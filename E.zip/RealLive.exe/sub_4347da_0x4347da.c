// 函数: sub_4347da
// 地址: 0x4347da
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
eax:1.b = arg7:1.b u>> 1
*0x89d84cc3
eax.b = *(arg4 + eax)
void arg_20

if (&arg_20 != 1 && arg6 == 1)
    jump(0x4347e7)

uint32_t esp = &arg7:3 u>> 1
*(esp - 4) = arg4
*(esp - 8) = arg3
undefined
