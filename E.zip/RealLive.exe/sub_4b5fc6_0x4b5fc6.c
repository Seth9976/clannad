// 函数: sub_4b5fc6
// 地址: 0x4b5fc6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t es
uint32_t var_4 = zx.d(es)
arg6 f- fconvert.t(*arg5)
int16_t entry_ebx
entry_ebx:1.b += arg3
int16_t ds
uint32_t var_8 = zx.d(ds)
*(arg5 + 0x5588bede) = neg.b(*(arg5 + 0x5588bede))
int16_t edx = arg2 - arg1
arg1.b &= 6
int32_t eflags
arg1.b = __in_al_immb(0xcf, eflags)
int16_t es_1 = edx
uint32_t* var_c = &var_8
entry_ebx.b = 0x48
edx.b -= 1
*0x3e53a787 += edx:1.b
uint32_t var_10 = zx.d(es_1)
*(arg4 + 3)
undefined
