// 函数: sub_486201
// 地址: 0x486201
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x7c) = arg2
int16_t ds
uint32_t var_4 = zx.d(ds)
int32_t eflags
bool c
void* eax_1 = adc.d(__in_oeax_immb(0x41, eflags), *arg2, c)
*(eax_1 - 0x7f) += eax_1:1.b
int32_t entry_ebx
*(entry_ebx - 0x31) = fconvert.d(arg6)
arg6 f- arg7
eax_1.b -= 0x2b
*arg1
uint8_t* edi
uint8_t temp0
temp0, edi = __insb(arg5, arg2.w, eflags)
*edi = temp0
*(eax_1 + 0x52)
*edi
undefined
