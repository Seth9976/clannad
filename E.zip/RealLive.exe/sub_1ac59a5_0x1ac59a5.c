// 函数: sub_1ac59a5
// 地址: 0x1ac59a5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1ac54a8(sub_1ac597f() + 0x1070, 0x1ac46b2)
