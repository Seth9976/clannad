// 函数: sub_418dc6
// 地址: 0x418dc6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
arg1.b = *(entry_ebx + arg1)
undefined
