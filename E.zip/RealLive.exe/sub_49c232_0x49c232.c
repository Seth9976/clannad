// 函数: sub_49c232
// 地址: 0x49c232
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx - 0x48e379aa)
unimplemented  {enter 0xbe95, 0x1}
*(arg1 - 0x2f) += &__return_addr
int32_t eflags
int32_t eax = __in_oeax_dx(arg2.w, eflags)
int32_t var_4 = arg2
*arg5
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*(eax - 0x40)
int32_t* var_8 = &var_4
int16_t* edi_1
int16_t temp0
temp0, edi_1 = __insd(arg5 + 1, arg2.w, eflags_1)
*edi_1 = temp0
*arg4 - *edi_1
undefined
