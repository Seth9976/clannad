// 函数: sub_4a662b
// 地址: 0x4a662b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1 = __sti(eflags)
void arg_2d
*(&arg_2d + (arg1 << 2)) = arg2.b
int32_t esi = __outsb(arg2.w, *arg3, arg3, eflags_1)
int32_t var_4 = arg1 | 0x27c9a11
int32_t var_c = arg2
int32_t ebx
int32_t var_10 = ebx
int32_t* var_14 = &var_10
int32_t var_1c = esi
int32_t var_20 = arg4
arg2:1.b u>>= 1
int32_t var_24 = ebx
*arg4
undefined
