// 函数: sub_4a10ba
// 地址: 0x4a10ba
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0xb89d852) -= arg1
void* entry_ebx
*(entry_ebx + 0xd)
undefined
