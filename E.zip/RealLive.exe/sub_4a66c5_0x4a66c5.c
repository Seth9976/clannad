// 函数: sub_4a66c5
// 地址: 0x4a66c5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
jump(entry_ebx)
