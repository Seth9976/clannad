// 函数: sub_442589
// 地址: 0x442589
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

unimplemented  {enter 0x8f47, 0xcf}
int32_t var_4 = arg1 - 1
undefined
