// 函数: sub_4bf001
// 地址: 0x4bf001
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t fs
*(arg4 + 0x6e683c89) = fs
int32_t eflags
int32_t eax
eax.b = __salc(eflags)
undefined
