// 函数: sub_4866d2
// 地址: 0x4866d2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4aac5b74) += (arg1 - 1).b
int32_t eax
eax.b = *arg4
void* esi = &arg4[1]
bool p = unimplemented  {add eax, 0xcc0ed3d8}
bool a = unimplemented  {add eax, 0xcc0ed3d8}
int16_t ds
uint32_t var_4 = zx.d(ds)
bool d
int32_t var_8 = (add_overflow(eax, 0xcc0ed3d8) ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa
    | (eax - 0x33f12c28 s< 0 ? 1 : 0) << 7 | (eax == 0x33f12c28 ? 1 : 0) << 6 | (a ? 1 : 0) << 4
    | (p ? 1 : 0) << 2 | (eax u>= 0x33f12c28 ? 1 : 0)
bool c0
bool c1
bool c2
bool c3
*(esi - 0x2fd79c39) =
    (c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe
int32_t eflags
int32_t eax_2
eax_2.b = __in_al_dx(arg2.w, eflags)
int32_t var_c = arg2
*esi
undefined
