// 函数: sub_40179e
// 地址: 0x40179e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
arg4 f- arg5
int32_t eflags
__out_dx_oeax(arg2, arg3, eflags)
undefined
