// 函数: sub_422ae6
// 地址: 0x422ae6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg4 + 0x41) = arg2:1.b
int32_t eax
eax:1.b = 0x7c
int32_t entry_ebx
eax.b = *(entry_ebx + eax)
undefined
