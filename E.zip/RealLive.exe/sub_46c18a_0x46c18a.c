// 函数: sub_46c18a
// 地址: 0x46c18a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __daa(arg1.b, eflags)
arg1.b = temp0
*(arg3 + 0x6b)
int16_t __return_addr_1
__return_addr = zx.d(__return_addr_1)
arg3:1.b = 0x49
void* var_4 = arg3
arg3.b = 0x55
*(arg1 + 0x53) += arg1:1.b
*(arg4 + 0x47) -= 0x33
int32_t gsbase
*(gsbase + arg3 - 0x4ae7c043)
undefined
