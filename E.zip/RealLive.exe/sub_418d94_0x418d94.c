// 函数: sub_418d94
// 地址: 0x418d94
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t cs
uint32_t var_4 = zx.d(cs)
*arg2 += arg5
*(arg1 - 0x74)
int32_t var_8 = arg1
arg2:1.b ^= arg3.b
arg1.b = sbb.b(arg1.b, 0x81, false)
int32_t entry_ebx
*(entry_ebx + (arg4 << 1) - 0x57)
*(entry_ebx + (arg4 << 1) - 0x57) = rol.d(*(entry_ebx + (arg4 << 1) - 0x57), 1)
bool c = unimplemented  {rol dword [ebx+ebp*2-0x57], 0x1}
arg2[-0x2f4dd3a] = rrc.d(arg2[-0x2f4dd3a], 1, c)
undefined
