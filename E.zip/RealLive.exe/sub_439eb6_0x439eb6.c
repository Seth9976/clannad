// 函数: sub_439eb6
// 地址: 0x439eb6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char temp0_1
temp0_1, eflags_1 = __daa(arg1.b, eflags)
arg1.b = temp0_1
int16_t x87status
int16_t temp0
temp0, x87status = __fnstcw_memmem16(arg4)
*(arg1 + arg3) = temp0
*arg2
undefined
