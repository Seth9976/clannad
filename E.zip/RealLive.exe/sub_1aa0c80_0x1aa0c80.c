// 函数: sub_1aa0c80
// 地址: 0x1aa0c80
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1ab7758(arg1, arg2, arg3, arg4)
