// 函数: sub_470362
// 地址: 0x470362
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t* entry_ebx
*(arg3 - 0x6c962f22) = entry_ebx.b
int32_t eflags
int32_t eax
eax.b = __in_al_dx(arg2, eflags)
eax.b = __in_al_dx(arg2, eflags)
*(entry_ebx + 0x1f9bbe75)
arg4 f- arg4
*(entry_ebx + 0x5a5cadb)
noreturn sub_47031d(&__return_addr:2, arg3 - *entry_ebx) __tailcall
