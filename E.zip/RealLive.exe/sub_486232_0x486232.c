// 函数: sub_486232
// 地址: 0x486232
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t edx
int16_t es
edx, es = __les_gprz_memp(*(arg2 - 0x51))
undefined
