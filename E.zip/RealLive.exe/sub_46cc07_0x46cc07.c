// 函数: sub_46cc07
// 地址: 0x46cc07
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* const* var_4 = &__return_addr
void* const** var_8 = &var_4
undefined
