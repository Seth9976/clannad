// 函数: sub_444145
// 地址: 0x444145
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b = 0x4d
arg1.b = 0x1d
int32_t entry_ebx
TEB* fsbase
bool c
void* ebx = sbb.d(entry_ebx, *(fsbase + arg4), c)
*arg5 = *arg4
void* esi = &arg4[1]
*(ebx + 0x18)
void* eax
eax.b = 0x4d
*(esi - 0x15827a8a) &= arg2.b
int32_t eflags
eax.b = __in_al_dx(arg2, eflags)
arg2.b |= *(eax + 0x738dbe8c)
undefined
