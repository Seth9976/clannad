// 函数: sub_4950b6
// 地址: 0x4950b6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
arg3:1.b = arg3:1.b
*arg3 |= arg1
void* const ebx
ebx:1.b = 0xca
bool p = unimplemented  {cmp eax, 0x5d6f14f8}

if (p)
    undefined

int32_t edi
return sub_4950c6(edi) __tailcall
