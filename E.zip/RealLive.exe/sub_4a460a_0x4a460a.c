// 函数: sub_4a460a
// 地址: 0x4a460a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* edx
bool c
edx:1.b = sbb.b((*(arg4 - 0x79)):1.b, *(arg3 + 0xba91ce), c)
*(edx - 0x2e) += &__return_addr
int32_t eflags
__out_dx_oeax(edx.w, arg1, eflags)
