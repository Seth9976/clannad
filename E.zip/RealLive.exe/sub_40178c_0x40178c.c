// 函数: sub_40178c
// 地址: 0x40178c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*arg1
*arg1 = &arg1[1]
undefined
