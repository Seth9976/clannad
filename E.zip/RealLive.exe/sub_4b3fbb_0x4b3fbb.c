// 函数: sub_4b3fbb
// 地址: 0x4b3fbb
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
int32_t eflags
arg1.b = __in_al_immb(0xcf, eflags)
return arg1
