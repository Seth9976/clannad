// 函数: sub_1a92935
// 地址: 0x1a92935
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1a92975(arg1, 0, 0)
