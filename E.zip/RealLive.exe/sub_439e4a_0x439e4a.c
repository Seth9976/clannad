// 函数: sub_439e4a
// 地址: 0x439e4a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char temp0_1
temp0_1, eflags_1 = __daa(arg1, eflags)
int16_t x87status
int16_t temp0
temp0, x87status = __fnstcw_memmem16(arg3)
int32_t entry_ebx
*(&__return_addr + entry_ebx) = temp0
*arg2
undefined
