// 函数: sub_4bcadb
// 地址: 0x4bcadb
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
eax.b = 0x4d
*arg2 = eax
int16_t entry_ebx
entry_ebx:1.b &= entry_ebx.b
undefined
