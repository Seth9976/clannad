// 函数: sub_4867e6
// 地址: 0x4867e6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4de67cad) = int.w(arg4)
trap(0x94)
