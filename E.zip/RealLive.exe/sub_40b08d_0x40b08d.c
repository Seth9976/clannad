// 函数: sub_40b08d
// 地址: 0x40b08d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*0xc700ae95 = ror.d(*0xc700ae95, arg3)
int32_t eax = arg9
arg9 = eax
arg8 = __return_addr
arg7 = arg6
*__return_addr
eax.b |= 0xc6
int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __daa(eax.b, eflags)
eax.b = temp0
int32_t eax_1
int16_t ecx_1
uint16_t edx_1
eax_1, edx_1, ecx_1 = 0xbd5f75a2()
int32_t ebx
ebx:1.b = arg6:1.b & ecx_1:1.b
__out_dx_oeax(edx_1, eax_1, eflags_1)
undefined
