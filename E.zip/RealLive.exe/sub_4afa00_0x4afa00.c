// 函数: sub_4afa00
// 地址: 0x4afa00
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 |= arg3.b
int32_t var_4 = 0xa75be4d8
*(arg4 - 0x30) = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
int32_t eflags
arg1.b = __in_al_immb(0x5b, eflags)
*arg5 - *arg6
void* esi = arg5 + 4
int32_t edi = arg6 + 4
*0x8b69d92 = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi - *edi
void* esi_1 = esi + 4
int32_t edi_1 = edi + 4
*0x8b69d92 = 0x1c855c81
arg2:1.b = 0xce
*esi_1 - *edi_1
int32_t edi_2 = edi_1 + 1
int32_t ebx
int32_t var_8 = ebx
*edi_2
*(esi_1 - 0x2fd507e5) = int.q(fconvert.t(*0x3dc61ece) / arg7)
*0xcbe18591
int32_t* var_c = &var_8
*edi_2
undefined
