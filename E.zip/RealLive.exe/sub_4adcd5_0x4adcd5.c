// 函数: sub_4adcd5
// 地址: 0x4adcd5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

__bound_gprv_mema32(arg2, *(arg5 - 0x4d4dcfaf))
*arg4 = arg5
*(arg3 + 0x416b6e23)
undefined
