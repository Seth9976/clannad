// 函数: sub_44f4d2
// 地址: 0x44f4d2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t entry_ebx
entry_ebx:1.b += arg2
*(arg1 + 0x93c1853)
*arg4
void* esi = &arg4[1]
*esi = rrc.b(*esi, 2, *arg4 u< *arg5)
arg1.b = *0x2bfacfeb
trap(0x54)
