// 函数: sub_480501
// 地址: 0x480501
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_4 = arg2
*(arg4 + 0x48b81d89)
*(arg4 + 0x48b81d89) s>>= arg3.b
bool c = unimplemented  {sar byte [edi+0x48b81d89], cl}
*arg4 = arg1
void* edi = &arg4[1]
int32_t var_8 = arg2
int32_t es
*(es + arg3 + 0xd55ce40) = rlc.b(*(es + arg3 + 0xd55ce40), arg3.b, c)
int32_t entry_ebx
int32_t var_c = entry_ebx - arg3
*(edi + 0x49103589) s>>= arg3.b
*edi = arg1
int32_t var_10 = arg2
int32_t eflags
int32_t eflags_1 = __cli(eflags)
*(arg3 - 0x32)
*0x491c3589 = arg1 | 0xd253cd2b
int32_t var_18 = arg2
__cli(eflags_1)
trap(0x41)
