// 函数: sub_1ac643e
// 地址: 0x1ac643e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (data_1c07648 == 0)
    LeaveCriticalSection(arg1 * 0x18 + &data_1c074b0)
