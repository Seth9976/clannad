// 函数: sub_4a6658
// 地址: 0x4a6658
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 += arg1.b
char* var_4 = arg1
int32_t var_c = arg2
int32_t ebx
int32_t var_10 = ebx
int32_t* var_14 = &var_10
int32_t ebp
int32_t var_18 = ebp
int32_t* var_1c = arg3
int32_t var_20 = arg4
int32_t eflags
__in_oeax_dx(arg2.w, eflags)
int32_t var_24 = ebp
*arg4
undefined
