// 函数: sub_4a66b5
// 地址: 0x4a66b5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_4 = arg1
*arg1
undefined
