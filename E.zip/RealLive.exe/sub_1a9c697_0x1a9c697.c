// 函数: sub_1a9c697
// 地址: 0x1a9c697
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

uint32_t eax_2 = zx.d(arg1)

if ((*(eax_2 + 0x1c091e1) & arg3) == 0)
    int32_t result
    
    if (arg2 == 0)
        result = 0
    else
        result = zx.d((*u"         (((((                  H")[eax_2]) & arg2
    
    if (result == 0)
        return result

return 1
