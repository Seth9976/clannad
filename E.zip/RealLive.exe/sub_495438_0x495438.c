// 函数: sub_495438
// 地址: 0x495438
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t var_4 = arg3.w
*(arg2 - 0x7b6ff77a)
*(arg2 - 0x7b6ff77a) ^= arg2:1.b
int32_t ecx
ecx:1.b = 0xca
int32_t var_6 = arg3
int32_t var_a = arg3
int32_t result = sx.d(arg1)
*(arg4 + 0x56d0042f) = rrc.b(*(arg4 + 0x56d0042f), 0x30, false)
*(result - 0x354ae07c) |= 0x86
int32_t var_e = arg3
int32_t var_12 = arg3
return result
