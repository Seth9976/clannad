// 函数: sub_486598
// 地址: 0x486598
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*0xda1ecc0a = arg1
bool c0
bool c1
bool c2
bool c3
*(arg2 - 0x2fd7a191) =
    (c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe
int32_t eflags
__out_immb_oeax(0xcf, &__return_addr, eflags)
void* entry_ebx
entry_ebx:1.b = *(entry_ebx + 0x7d4354c1)
undefined
