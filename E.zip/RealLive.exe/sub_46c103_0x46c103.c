// 函数: sub_46c103
// 地址: 0x46c103
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
arg1.b = __in_al_dx(arg2, eflags)
int32_t edx = arg6
int32_t eax = arg8
*(arg5 - 0x6a5f4ae2)
arg8 = arg4
*(__return_addr - 0x69) u>>= 1
*__return_addr = eax
void* edi_1 = __return_addr + 4
int32_t ecx
ecx:1.b = 0x27
void* ebp_1 = arg7
bool c = unimplemented  {shl esi, cl}
*(ebp_1 + 0x64c483be) = rlc.b(*(ebp_1 + 0x64c483be), ecx.b, c)
*(edx + (edi_1 << 1) + 0x5ca4cfaf)
*(&arg6:1 + (eax << 2))
ecx.b = 0x55
*(ebp_1 + 0x53) += ebp_1:1.b
*(edi_1 + 0x47) -= 0x33
int32_t gsbase
*(gsbase + ecx - 0x4ae7c043)
undefined
