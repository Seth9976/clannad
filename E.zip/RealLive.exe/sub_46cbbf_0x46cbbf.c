// 函数: sub_46cbbf
// 地址: 0x46cbbf
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t var_4 = &__return_addr
arg1 f- arg2
undefined
