// 函数: sub_1a92a1a
// 地址: 0x1a92a1a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1a976dc(0xd)
