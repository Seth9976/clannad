// 函数: sub_49c222
// 地址: 0x49c222
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t entry_ebx
entry_ebx:1.b |= entry_ebx.b
undefined
