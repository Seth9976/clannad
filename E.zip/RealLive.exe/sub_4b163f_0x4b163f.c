// 函数: sub_4b163f
// 地址: 0x4b163f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
int32_t ecx
ecx:1.b = 0xcb
undefined
