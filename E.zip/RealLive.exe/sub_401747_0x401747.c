// 函数: sub_401747
// 地址: 0x401747
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

undefined
