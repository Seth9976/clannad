// 函数: sub_1a92908
// 地址: 0x1a92908
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax_1 = data_1bf9d48

if (eax_1 != 0)
    eax_1()

sub_1a92a2c(0x1adc5e8, 0x1adc900)
return sub_1a92a2c(0x1adc000, 0x1adc4e4)
