// 函数: sub_495524
// 地址: 0x495524
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
int32_t esi = sbb.d(arg4, *(arg1 + (arg5 << 1) - 0x3a4ae17b), c)
bool c_1 = unimplemented  {sbb esi, dword [eax+edi*2-0x3a4ae17b]}
void* entry_ebx
*arg5 = sbb.b(*arg5, entry_ebx:1.b, c_1)
*arg1 += arg1
int32_t* var_4 = arg1
int32_t var_c = arg2
void* var_10 = entry_ebx
int32_t* var_14 = &var_10
int32_t var_18 = arg3 - 1
int32_t var_1c = esi
char* var_20 = arg5
int32_t eflags
__in_oeax_dx(arg2.w, eflags)
*(entry_ebx - 0x51) ^= arg2.b
undefined
