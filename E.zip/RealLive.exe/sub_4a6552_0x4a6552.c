// 函数: sub_4a6552
// 地址: 0x4a6552
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_4
int32_t eip
eip, eflags_4 = __into(eflags)
arg1.b &= arg2:1.b
void* esp = &__return_addr - *(arg4 - 0x6a8aceef)
int32_t* esi = __outsd(arg2.w, *0x4c288d00, 0x4c288d00, eflags_4)
*arg5 = arg1.b
void* edi = &arg5[1]
*(esp - 4) = esp

if ((*0xf60c406e & arg3:1.b) s>= 0)
    *edi
    undefined

arg1.b |= 0xb2

if (arg1.b u< 0)
    *(esp - 8) = arg4
    *edi
    undefined

*(esp - 8) = arg1
*(esp - 0xc) = arg3
*(esp - 0x10) = arg2
*(esp - 0x14) = 0x8831cac0
*(esp - 0x18) = esp - 0x14
*(esp - 0x1c) = arg4
*(esp - 0x20) = esi
*(esp - 0x24) = edi
int32_t eflags_2
char temp0_1
temp0_1, eflags_2 = __das(arg1.b, eflags_4)
arg1.b = temp0_1
unimplemented  {enter 0x53ce, 0xbe}
*(esp - 0x24)
*(arg2 - 0x6e7df271)
__cli(eflags_2)
*(esp - 0x26) = arg3
*arg1
undefined
