// 函数: sub_4a1094
// 地址: 0x4a1094
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ecx
ecx.b = 0xeb
*arg1
undefined
