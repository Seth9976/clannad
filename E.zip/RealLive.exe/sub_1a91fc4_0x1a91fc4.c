// 函数: sub_1a91fc4
// 地址: 0x1a91fc4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (arg1 u<= 0xffffffe0)
    bool cond:1_1
    
    do
        void* result = sub_1a91ff0(arg1)
        
        if (result != 0 || arg2 == result)
            return result
        
        cond:1_1 = sub_1a97794(arg1) != 0
    while (cond:1_1)

return nullptr
