// 函数: sub_4c484a
// 地址: 0x4c484a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__outsb(arg2.w, *arg4, arg4, eflags)
uint64_t* eax
eax.b = 0x4d
eax.b = 0xb9
int32_t eflags_1
char temp0
char temp1
temp0, temp1, eflags_1 = __aad_immb(0xbd, 0xb9, eax:1.b)
eax.b = temp0
eax:1.b = temp1
*(arg2 + 0x3d)
int32_t ebp = arg3 ^ *(arg2 + 0x3d)
int32_t ebx_2
int16_t es
ebx_2, es = __les_gprz_memp(*eax)
int32_t ds
*(adc.d(arg1, *(ds + ebp + 3), false) + 0x4d)
*(ebp - 0xf)
*0xdf31f883 - *arg5
undefined
