// 函数: sub_46c1ce
// 地址: 0x46c1ce
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eax
eax.b = __in_al_dx(arg2.w, eflags)
int32_t entry_ebx
int32_t var_4 = entry_ebx
bool c
bool p
bool a
bool z
bool s
bool d
bool o
int32_t var_8 = (o ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa | (s ? 1 : 0) << 7 | (z ? 1 : 0) << 6
    | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (c ? 1 : 0)
void var_97bab79
char edx = (adc.d(arg2, &var_8, *(&var_97bab79 + arg4) u< &var_8)).b
void* eax_1
eax_1.b = *(entry_ebx + arg3)
int32_t var_c = entry_ebx
*arg4
void* edi = arg4 + 4
arg1:1.b |= *(entry_ebx + (edi << 1) + 0x7d99bc6b)
arg1.b = 0x55
*(eax_1 + 0x53) += eax_1:1.b
*(edi + 0x47) -= edx
int32_t gsbase
*(gsbase + arg1 - 0x4ae7c043)
undefined
