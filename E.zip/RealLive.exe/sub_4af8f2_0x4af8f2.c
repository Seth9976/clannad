// 函数: sub_4af8f2
// 地址: 0x4af8f2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 |= arg3.b
int32_t var_4 = 0xa75be4d8
*(arg4 - 0x30) = 0x168c5c81
void* entry_ebx
void* esp = &var_4 + *(entry_ebx - 0x28)
int32_t eflags
arg1.b = __in_al_immb(0x5b, eflags)
*arg5 - *arg6
int32_t esi = arg5 + 4
void* edi = arg6 + 4
*0x3b69d92 = 0x168c5c81
*(entry_ebx - 0x2d) |= arg1:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi - *edi
void* edi_1 = edi + 4
*0x8b69d92 = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
__out_dx_oeax(arg2, arg1, eflags)
*(esp - 4) = arg1
*(esi + 4) - *edi_1
*0x8b69d92 = 0x168c5c81
arg1[0xffffffd8] |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*(edi_1 + 4) = arg1
undefined
