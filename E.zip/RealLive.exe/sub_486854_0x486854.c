// 函数: sub_486854
// 地址: 0x486854
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t* edi_1 = *(arg2 + 0x7d9e54c1) * 0xdd52cafd
*(arg1 - 0x31) += (arg1 - 1):1.b
int32_t eax_1
int32_t ecx
eax_1, ecx = 0x4a1413be()
*(arg3 - 0x4ee57fb0)
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
int32_t eax_3
int32_t ecx_2
eax_3, ecx_2 = 0x4a1413d0()
*(arg3 - 0x4ee57fb0)
int32_t eflags_2
int32_t eip_1
eip_1, eflags_2 = __into(eflags_1)
int32_t eax_5
int32_t ecx_4
eax_5, ecx_4 = 0x4a1413e2()
*(arg3 - 0x4ee57fb0)
int32_t eflags_3
int32_t eip_2
eip_2, eflags_3 = __into(eflags_2)
int32_t eax_7
int32_t ecx_6
eax_7, ecx_6 = 0x4a1413f4()
*(arg3 - 0x4ee57fb0)
int32_t eflags_4
int32_t eip_3
eip_3, eflags_4 = __into(eflags_3)
int32_t eax_9
int32_t ecx_8
eax_9, ecx_8 = 0x4a141406()
*(arg3 - 0x4ee57fb0)
int32_t eflags_5
int32_t eip_4
eip_4, eflags_5 = __into(eflags_4)
__out_dx_al(0x404, ecx_8.b, eflags_5)
int32_t* var_4 = edi_1
*edi_1 = ecx_8
undefined
