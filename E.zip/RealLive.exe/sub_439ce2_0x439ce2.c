// 函数: sub_439ce2
// 地址: 0x439ce2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_4 = arg2 - 1
undefined
