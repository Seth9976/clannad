// 函数: sub_4adfc6
// 地址: 0x4adfc6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg5 += arg3:1.b
*(arg4 + 0x71fdf53) += arg1:1.b
arg6 f- fconvert.t(*arg1)
int16_t ds
uint32_t var_4 = zx.d(ds)
arg1.b += 0x1a
*(arg4 - 0x2fd52f1e) = int.q(arg7)
int32_t eflags
__out_dx_oeax(arg2 - 1, arg1, eflags)
arg3:1.b &= 0xcf
__outsb(arg2 - 1, *arg4, arg4, eflags)
uint32_t* var_8 = &var_4
int16_t entry_ebx
int16_t ebx
ebx:1.b = ror.b((entry_ebx | arg1.w):1.b, 0xff)
undefined
