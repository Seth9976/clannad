// 函数: sub_1ac597f
// 地址: 0x1ac597f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t result = *(sub_1ac54a8(0x1c0724c, 0x1ac467e) + 4)

if (result != 0)
    return result

return sub_1ac556a(0x1c07248, 0x1ac59f1)
