// 函数: sub_4be53f
// 地址: 0x4be53f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
*0xd382bede = rol.d(*0xd382bede, arg3)
int32_t eflags
arg1.b = __in_al_immb(0xcf, eflags)
undefined
