// 函数: sub_4954b8
// 地址: 0x4954b8
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
entry_ebx.b &= *(arg1 + 0x3effff47)
bool c
*((sbb.d(&__return_addr, *(arg1 - 0x1b), c) ^ arg1) - 4) = arg1
*(entry_ebx - 0x52) -= arg2 - 1
undefined
