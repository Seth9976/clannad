// 函数: sub_4192a4
// 地址: 0x4192a4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp1_2 = arg1.b
arg1.b += arg3:1.b
int32_t eflags
arg1.b = __salc(eflags)
char* entry_ebx
arg2.b = sbb.b(arg2.b, *entry_ebx, temp1_2 + arg3:1.b u< temp1_2)
arg1.b = *arg4
void* esi = &arg4[1]
char temp2 = arg1.b
arg1.b -= 0xb
void* const __return_addr_1 = __return_addr
__return_addr = arg1
void* var_4 = arg3
int32_t var_8 = arg2
char* var_c = entry_ebx
char** var_10 = &var_c
void* const __return_addr_2 = __return_addr_1
void* var_18 = esi
void** var_1c = arg5
*(&__return_addr:2 + (arg1 << 2)) = arg2.b

if (temp2 - 0xb s< 0)
    arg2:1.b = sbb.b(arg2:1.b, *(arg3 + 0x4ba91ce), temp2 u< 0xb)
    arg1.b += 0x64
    int32_t eflags_2
    char temp0_4
    char temp1_1
    temp0_4, temp1_1, eflags_2 = __aam_immb(0xe8, arg1.b)
    arg1.b = temp0_4
    arg1:1.b = temp1_1
    void** var_20 = arg5
    *arg5 = arg1
    undefined

arg1.b |= 0xd8
int32_t eflags_1
char temp0_1
char temp1
temp0_1, temp1, eflags_1 = __aam_immb(0xbe, arg1.b & 0xc5)
int32_t eax_1 = *esi
int32_t eax_3
eax_3.b = __in_al_dx(eax_1.w, eflags_1)
int32_t var_1c_1 = eax_1
*(esi + 4)
undefined
