// 函数: sub_427044
// 地址: 0x427044
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_4 = 0
void* entry_ebx
*(entry_ebx - 0x3b)
*(entry_ebx - 0x3b) = arg2 | arg1
undefined
