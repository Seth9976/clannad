// 函数: sub_49c22a
// 地址: 0x49c22a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
*(arg2 + 0x11) += entry_ebx.b
*arg3 = *arg2
int32_t var_4 = entry_ebx
arg3[1]
undefined
