// 函数: sub_4c130a
// 地址: 0x4c130a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 += arg1.b
*(arg3 + 0x6c) -= arg1.b
arg1.b -= 0x28
arg1.b &= 0xaf
undefined
