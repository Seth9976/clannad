// 函数: j_sub_523927
// 地址: 0x523910
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_523927() __tailcall
