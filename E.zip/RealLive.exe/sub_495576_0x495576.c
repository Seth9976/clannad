// 函数: sub_495576
// 地址: 0x495576
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0x1ab440f0) = ror.b(*(arg2 + 0x1ab440f0), arg1.b)
*arg3
*(arg1 + 0x4d) ^= arg1:1.b
*((arg1 << 3) + 0x94ce881e) += arg1
*(arg3 + 4)
undefined
