// 函数: __unlock
// 地址: 0x1a9773d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return LeaveCriticalSection(*((arg1 << 2) + &data_1bfc0d8))
