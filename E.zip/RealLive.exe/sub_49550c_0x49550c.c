// 函数: sub_49550c
// 地址: 0x49550c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx - 0x52) -= arg2
undefined
