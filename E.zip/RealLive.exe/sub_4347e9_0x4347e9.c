// 函数: sub_4347e9
// 地址: 0x4347e9
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
bool c
*(entry_ebx - 0x51) = adc.b(*(entry_ebx - 0x51), arg2, c)
undefined
