// 函数: sub_401720
// 地址: 0x401720
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b += arg1:1.b
*arg2
*arg2 = &arg2[1]
int16_t* entry_ebx
*entry_ebx
undefined
