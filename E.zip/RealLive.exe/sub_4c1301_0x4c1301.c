// 函数: sub_4c1301
// 地址: 0x4c1301
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg4 + 0x51)
undefined
