// 函数: sub_4a44ed
// 地址: 0x4a44ed
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

long double result = arg6 * float.t(*(arg3 - 0x17163cf7))
*arg4
void* entry_ebx
*(entry_ebx - 0x39)
*(entry_ebx - 0x39) u>>= 1
*(arg5 - 0x25f8f02c)
*arg3 = arg3
return result
