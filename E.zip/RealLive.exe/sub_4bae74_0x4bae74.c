// 函数: sub_4bae74
// 地址: 0x4bae74
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*(arg2 - 0x41) += arg1
undefined
