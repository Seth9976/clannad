// 函数: sub_4866ec
// 地址: 0x4866ec
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return arg3 + fconvert.t(*(arg1 - 0x42e973a4))
