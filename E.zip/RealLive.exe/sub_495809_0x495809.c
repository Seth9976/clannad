// 函数: sub_495809
// 地址: 0x495809
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

trap(0x1e)
