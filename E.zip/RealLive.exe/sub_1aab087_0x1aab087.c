// 函数: sub_1aab087
// 地址: 0x1aab087
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_8 = arg1
var_8 = 0x1c05828
sub_1a942c7(&var_8, 0x1ada700)
noreturn
