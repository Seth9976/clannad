// 函数: sub_4b1598
// 地址: 0x4b1598
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg4 f- arg5
*(arg3 - 1)
int16_t entry_ebx
entry_ebx:1.b |= arg2:1.b
undefined
