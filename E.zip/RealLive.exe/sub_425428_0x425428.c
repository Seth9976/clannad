// 函数: sub_425428
// 地址: 0x425428
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
*(__return_addr - 4) = entry_ebx
*arg1
undefined
