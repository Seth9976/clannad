// 函数: sub_439e54
// 地址: 0x439e54
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*__return_addr = *0x28539ffe
void* edi_1 = __return_addr + 1
void* esi = 0x28539fff
int32_t eflags
int32_t eflags_1
char temp0_1
temp0_1, eflags_1 = __daa(arg1.b, eflags)
arg1.b = temp0_1
void* entry___return_addr
bool c

if (arg4 != 1 && not(c))
    *arg2 = adc.b(*arg2, entry___return_addr:1.b, c)
    int16_t var_30[0x16]
    es
    var_30[arg3 * 4] = es
    __return_addr = entry___return_addr
    *edi_1
    void* edi_2 = edi_1 + 4
    *esi - *edi_2
    *(edi_2 + 4)
    jump(0x439ec6)

__return_addr = entry___return_addr

if (arg4 - 1 s< 0 == add_overflow(arg4, 0xffffffff))
    return sub_439e42(arg4 - 1, edi_1) __tailcall

*edi_1 = *esi
int16_t ds
uint32_t var_4 = zx.d(ds)
arg3:1.b = 0xa0
entry___return_addr:1.b = 0x33
*(&var_4 + ((edi_1 + 1) << 1))
int16_t eax
eax:1.b = (arg1 - 1):1.b u>> 0x53
undefined
