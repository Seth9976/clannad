// 函数: sub_416a36
// 地址: 0x416a36
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* const __return_addr_1 = __return_addr
int32_t eflags

if (arg5 s>= 0xffffff9e)
    arg1.b = __in_al_immb(0xad, eflags)
    arg4 -= 1

__return_addr = arg1
int32_t var_4 = 0xffffffd8
*(arg4 + 0x354ae302)
*(__return_addr_1 - 0x7f)
*(__return_addr_1 - 0x7f) |= 0x15
*__return_addr_1
int16_t var_8 = arg4.w
*(arg4 - 0x7f) ^= 0x15
*__return_addr_1
void* var_a = arg4
*(arg3 - 0x7f) ^= 0x15
*__return_addr_1
int32_t var_e = 0x354ae34a
void* eax_3
eax_3.b = (adc.d(arg1 ^ 0x2e8d1461, 0xe552adc, false) | 0x8b1fce89).b | 0x89
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
*0x6a95c682
*(arg3 - 0x7f) += 0x15
*__return_addr_1
int32_t var_10 = 0x354ae34a

if ((arg3 | *(arg3 - 0x4274e032)) != 0)
    jump(0x416ab1)

*(eax_3 - 0x7f) += 0x15
*__return_addr_1
int32_t var_14 = 0x354ae34a
undefined
