// 函数: sub_4c4843
// 地址: 0x4c4843
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return arg1 ^ 0x80782454
