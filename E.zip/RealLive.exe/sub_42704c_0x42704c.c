// 函数: sub_42704c
// 地址: 0x42704c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1:1.b = rol.b(arg1:1.b, 0x12)
void* entry_ebx
int32_t ds

if ((*(ds + arg4 + (arg5 << 2) + 0x1b) & arg2:1.b) != 0)
    *(entry_ebx - 0x15) += arg2.b
    unimplemented  {enter 0xaf93, 0xcf}
    int32_t var_5 = arg4 - 1
    undefined

void arg_1e
*(&arg_1e + (arg1 << 2)) = adc.d(*(&arg_1e + (arg1 << 2)), arg2, false)
int32_t eflags
__out_immb_al(0x41, arg1.b, eflags)
*(arg2 - 0x2f9fff68) |= entry_ebx
*(arg3 - 0x20e111ac)
undefined
