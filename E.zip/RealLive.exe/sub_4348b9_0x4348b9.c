// 函数: sub_4348b9
// 地址: 0x4348b9
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return arg2 * fconvert.t(*(arg1 - 0x57687bac))
