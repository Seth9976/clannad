// 函数: sub_46cbd5
// 地址: 0x46cbd5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
*((arg2 | entry_ebx) + 0x19b3cfe9)
undefined
