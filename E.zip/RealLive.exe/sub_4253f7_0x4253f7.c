// 函数: sub_4253f7
// 地址: 0x4253f7
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax = *arg2
void* esi = &arg2[1]
*esi
int32_t ecx
ecx:1.b = 0x9a
int16_t ds
uint32_t var_5 = zx.d(ds)
*(eax + (arg1 << 2))
int32_t var_9 = eax
int32_t var_d = ecx
int32_t entry_ebx
int32_t var_15 = entry_ebx
int32_t* var_19 = &var_15
int32_t var_1d = arg1
void* var_21 = esi
eax:1.b u>>= 1
eax:1.b += *(entry_ebx + (eax << 2))
*(entry_ebx * 9 - 0x26c52f21)
eax.b &= 0x43
*(ecx * 5 + 0x54)
ecx.b = 0xc2
*0x2ecd05c = eax
trap(0xd)
