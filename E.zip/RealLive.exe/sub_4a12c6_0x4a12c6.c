// 函数: sub_4a12c6
// 地址: 0x4a12c6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ss
uint32_t var_4 = zx.d(ss)
bool c
void* eax = sbb.d(arg1, *arg2, c)
*(eax + 0x20fe3e3e) |= eax:1.b
*arg4 - *arg5
void* entry_ebx
entry_ebx:1.b u>>= 1
*(arg3 - 0x28) = ror.b(*(arg3 - 0x28), 1)
entry_ebx.b += *(entry_ebx + 0x1c42fc57)
arg2:1.b = 0x4b
*(arg2 - 0x102fa7a7)
*(arg3 - 0x28) = ror.b(*(arg3 - 0x28), 1)
int32_t eax_1
eax_1.b = *(entry_ebx + 0x405b6062)
*(var_4 + entry_ebx) |= var_4
int32_t ecx
ecx:1.b = 0xca
int32_t eflags
__in_oeax_immb(0xc3, eflags)
(&__return_addr)[(arg4 + 1) * 2]
breakpoint
