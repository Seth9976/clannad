// 函数: sub_1a97794
// 地址: 0x1a97794
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax_3 = data_1c077a4

if (eax_3 != 0 && eax_3(arg1) != 0)
    return 1

return 0
