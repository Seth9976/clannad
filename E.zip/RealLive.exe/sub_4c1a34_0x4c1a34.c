// 函数: sub_4c1a34
// 地址: 0x4c1a34
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_4 = arg1
int32_t edx
edx.b = 0xc3
(&var_4)[arg2 * 2]
trap(0xd)
