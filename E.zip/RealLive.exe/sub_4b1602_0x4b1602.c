// 函数: sub_4b1602
// 地址: 0x4b1602
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4de67cad) = int.w(arg4)
trap(0x92)
