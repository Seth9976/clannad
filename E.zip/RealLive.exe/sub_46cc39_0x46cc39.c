// 函数: sub_46cc39
// 地址: 0x46cc39
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__out_dx_oeax(arg2, arg1, eflags)
int16_t* edi
int16_t temp0
temp0, edi = __insd(arg3, arg2, eflags)
*edi = temp0
undefined
