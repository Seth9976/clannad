// 函数: sub_495081
// 地址: 0x495081
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x5be113ac)
*arg5 = *arg4
*(arg1 - 4) = &arg4[1]
int32_t eflags
int32_t eflags_1
char temp0
bool c
bool p
bool a
bool z
bool s
temp0, eflags_1 = __das(
    (s ? 1 : 0) << 7 | (z ? 1 : 0) << 6 | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (c ? 1 : 0), eflags)
undefined
