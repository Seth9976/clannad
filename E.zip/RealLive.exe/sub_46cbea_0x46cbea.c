// 函数: sub_46cbea
// 地址: 0x46cbea
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 + 0x5953aa13) += arg2:1.b
return arg1 | 0x9792d80b
