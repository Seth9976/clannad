// 函数: sub_4950c8
// 地址: 0x4950c8
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
void* entry_ebx
*(entry_ebx - 0x4cb8fca5) &= entry_ebx.b
undefined
