// 函数: sub_482081
// 地址: 0x482081
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__out_immb_al(0xf9, arg1, eflags)
int32_t entry_ebx
jump(entry_ebx)
