// 函数: sub_4a666c
// 地址: 0x4a666c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg2:1.b &= arg2.b
int32_t eflags
int32_t eax
eax.b = __in_al_dx(arg2.w, eflags)
int32_t entry_ebx
int32_t var_4 = entry_ebx
eax.b = *(entry_ebx + eax)
int32_t esp
int16_t es
esp, es = __les_gprz_memp(*(arg3 * 5 + 0x64))
char temp0_1 = *arg4
*arg4 = entry_ebx.b
entry_ebx.b = temp0_1
*(arg2 - 0x2f9ffd84) -= entry_ebx
__in_oeax_immb(0xdd, eflags)
*(esp - 4) = arg2
*arg4
unimplemented  {enter 0xad63, 0xcf}
*(esp - 5)
undefined
