// 函数: sub_434786
// 地址: 0x434786
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_c = arg2
int32_t ebx
int32_t var_10 = ebx
int32_t* var_14 = &var_10
int32_t var_18 = arg3 - 1
int32_t var_1c = arg4
int32_t var_20 = arg5
int32_t eflags
__in_oeax_dx(arg2.w, eflags)
int32_t* var_24 = &var_20
*arg4
int32_t var_28 = arg2
int32_t var_28_1 = ebx
*arg5
undefined
