// 函数: sub_4a65e5
// 地址: 0x4a65e5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1
*arg1
int32_t eflags
int32_t eax_1
eax_1.b = __in_al_dx(arg2.w, eflags)
int32_t entry_ebx
int32_t var_8 = entry_ebx
*arg3
char* edi = arg3 + 4
*(entry_ebx + (edi << 3) + 0x7f) = arg2
*0x62974518 = rol.d(*0x62974518, 0x9f)
int32_t eflags_1
char temp0_2
temp0_2, eflags_1 = __das(eax_1.b, eflags)
eax_1.b = temp0_2
int32_t* esi = __outsd(arg2.w, *0x66e40f00, 0x66e40f00, eflags_1)
*edi = eax_1.b
void* edi_1 = &edi[1]
int32_t* var_c = &var_8
int32_t eax

if ((*0xb20c406e & arg1:1.b) u< 0)
    int32_t var_10_1 = eax
    *edi_1
    undefined

int32_t var_10 = eax_1
int32_t var_14 = arg1
void* var_18 = arg2
int32_t var_1c = 0x889fcac0
int32_t* var_20 = &var_1c
int32_t var_24 = eax
int32_t* var_28 = esi
int16_t var_2c = edi_1.w
int32_t eflags_2
char temp0_3
temp0_3, eflags_2 = __das(eax_1.b, eflags_1)
eax_1.b = temp0_3
unimplemented  {enter 0x53ce, 0xbe}
*(arg2 - 0x6e7df271)
__cli(eflags_2)
int32_t var_2e = arg1
*eax_1
undefined
