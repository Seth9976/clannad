// 函数: sub_41674f
// 地址: 0x41674f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

trap(0xd)
