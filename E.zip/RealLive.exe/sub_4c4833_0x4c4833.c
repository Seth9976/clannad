// 函数: sub_4c4833
// 地址: 0x4c4833
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg2 = rrc.d(*arg2, 0xd0, c)
void* eax
void* edx
int32_t esi
return sub_4c48a7(eax, edx, esi, arg2) __tailcall
