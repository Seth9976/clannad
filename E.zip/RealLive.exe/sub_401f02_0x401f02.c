// 函数: sub_401f02
// 地址: 0x401f02
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg3
*arg3 = &arg3[1]
bool z
bool s
bool o

if (not(z) && s == o)
    undefined

char* entry_ebx
*entry_ebx += arg2
undefined
