// 函数: sub_40b0b0
// 地址: 0x40b0b0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp1 = arg1.b
arg1.b += 0x77
int32_t ebp = *arg4
*arg4 = &arg4[1]
*arg1 = adc.d(*arg1, arg1, temp1 u>= 0x89)
*(arg4 - 4) = arg1
*(arg4 - 8) = arg3
*(arg4 - 0xc) = 0xa5caf5b0
int32_t entry_ebx
*(arg4 - 0x10) = entry_ebx
*(arg4 - 0x14) = arg4 - 0x10
*(arg4 - 0x18) = ebp
*(arg4 - 0x1c) = arg5
*(arg4 - 0x20) = arg6
arg1.b = *arg5
*(arg4 - 0x24) = entry_ebx
*(arg6 + 0xd)
return arg7 * fconvert.t(*(arg3 - 0x42e373ab))
