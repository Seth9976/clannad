// 函数: sub_4adfbc
// 地址: 0x4adfbc
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 0x36c7ba9) = int.d(arg4)
undefined
