// 函数: sub_1a9f073
// 地址: 0x1a9f073
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (arg3 == 0)
    return 0

enum COMPARESTRING_RESULT eax_1 = sub_1a9fa7d(data_1c092e4, 1, arg1, arg3, arg2, arg3, data_1c09058)

if (eax_1 != 0)
    return eax_1 - 2

return 0x7fffffff
