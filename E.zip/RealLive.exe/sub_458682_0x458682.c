// 函数: sub_458682
// 地址: 0x458682
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 + 0x1f670164) |= 0x8b
