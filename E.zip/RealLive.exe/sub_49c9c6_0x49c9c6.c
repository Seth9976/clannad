// 函数: sub_49c9c6
// 地址: 0x49c9c6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
int32_t var_4 = eax
int32_t ebx
int32_t var_10 = ebx
int32_t* var_14 = &var_10
int32_t var_20 = arg1
int32_t var_24 = ebx
*arg1
undefined
