// 函数: sub_4adc81
// 地址: 0x4adc81
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg2
void* entry_ebx
entry_ebx.b -= __return_addr.b
int16_t __return_addr_1
__return_addr = zx.d(__return_addr_1)
*arg3 = arg1
*(entry_ebx + 0x5138f4e4) |= 0x54c6cfaf
undefined
