// 函数: sub_439c81
// 地址: 0x439c81
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
arg3:1.b = sbb.b(arg3:1.b, arg3:1.b, c)
unimplemented  {enter 0x8f4f, 0xcf}
arg1.b += 0x6c
*(arg5 + 0x37) <<= 1
int32_t var_3 = 0x35
void arg_4aa0a0d4
int32_t entry_ebx
*(&arg_4aa0a0d4 + (entry_ebx << 3)) &= 0x73
*(arg5 - 0x55)
__rsqrtps_xmmps_memps(*(arg3 + 0xcb31cd2))
*arg3
*0xb2304467 = rol.b(*0xb2304467, 1)
int32_t var_7 = entry_ebx
undefined
