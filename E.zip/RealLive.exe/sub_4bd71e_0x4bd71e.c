// 函数: sub_4bd71e
// 地址: 0x4bd71e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax = *0x539311c4
*(arg1 + eax - 4) += 1
arg1:1.b = 6
trap(6)
