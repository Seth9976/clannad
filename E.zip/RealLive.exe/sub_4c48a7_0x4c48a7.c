// 函数: sub_4c48a7
// 地址: 0x4c48a7
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool o

if (o)
    *(arg2 - 0x416a3d40)
    *(arg1 + 0x3f)

*arg3 - *arg4
undefined
