// 函数: sub_416884
// 地址: 0x416884
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 - 0x7d) += 0x6f
int32_t edx
int32_t var_4 = edx
int32_t var_8 = edx
*arg2
undefined
