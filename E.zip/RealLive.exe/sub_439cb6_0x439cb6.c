// 函数: sub_439cb6
// 地址: 0x439cb6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b &= 0x1c
int16_t eax
eax:1.b = (arg1 + 1):1.b u>> 1
*(arg5 - 0x2427d0c1)
eax.b += 0x6c
*0xcc43d6a
*0xcc43d6a
int32_t eflags
int16_t eax_2
void* edx
edx:eax_2 = sx.q(__in_oeax_immb(0x10, eflags))
int32_t entry_ebx
*(entry_ebx + (arg3 << 1)) = sbb.b(*(entry_ebx + (arg3 << 1)), eax_2:1.b, false)
bool c = unimplemented  {imul eax, esp, 0x748454a9}
*(edx - 0x2f9fefe4) = sbb.d(*(edx - 0x2f9fefe4), entry_ebx, c)
*(entry_ebx - 0x41)
undefined
