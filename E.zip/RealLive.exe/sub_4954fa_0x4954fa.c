// 函数: sub_4954fa
// 地址: 0x4954fa
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx - 0x52) -= arg2
undefined
