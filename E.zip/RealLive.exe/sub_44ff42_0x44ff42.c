// 函数: sub_44ff42
// 地址: 0x44ff42
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char temp0_1
temp0_1, eflags_1 = __daa(arg1.b, eflags)
arg1.b = temp0_1
int32_t entry_ebx
bool c
*(entry_ebx * 9) = rrc.b(*(entry_ebx * 9), 0x86, 
    adc.d(arg1, 0xda07ab74, c) u< arg1 || (c && adc.d(arg1, 0xda07ab74, c) == arg1))
int32_t var_4 = entry_ebx
jump(*arg2)
