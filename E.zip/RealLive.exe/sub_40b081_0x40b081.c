// 函数: sub_40b081
// 地址: 0x40b081
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*(arg2 - 0xbdb74f8) = rrc.d(*(arg2 - 0xbdb74f8), 0xe0, c)
void* eax
int16_t* esi
int32_t edi
return sub_40b0ea(eax, arg2, arg1 + 1, esi, edi) __tailcall
