// 函数: sub_4b6d3e
// 地址: 0x4b6d3e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg5 - 0x5dac584a) += arg1:1.b
arg7 f- arg9
char* ecx = arg3 ^ arg6
int16_t ds
uint32_t var_4 = zx.d(ds)
*(arg4 + 0x6805bede) = sbb.d(*(arg4 + 0x6805bede), arg4, false)
int32_t edx = arg2 - arg1
arg1.b = *0xb9cfe43b
arg1.b = 0xc2
uint32_t* var_8 = &var_4
int32_t entry_ebx
arg1.b = *(entry_ebx - 1 + arg1)
ecx[(arg6 << 2) - 0x59a3ac59] += edx:1.b
int16_t es
*0xe8cafe73 = zx.d(es)
*(ecx - 0x1de130c2)
arg1.b = *0x6a76bede
*ecx &= ((entry_ebx - 1).w - 1):1.b
int32_t eflags
arg1.b = __in_al_immb(0xcf, eflags)
int32_t esp = *0xe8cafe73
int16_t ebx
ebx.b = 0xc2
*(esp - 4) = esp
*(arg4 - 2) <<= 1
undefined
