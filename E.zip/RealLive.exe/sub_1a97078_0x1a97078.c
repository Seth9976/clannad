// 函数: sub_1a97078
// 地址: 0x1a97078
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void** i = &data_1bfa0b0

do
    if (arg1 u> i[4] && arg1 u< i[5])
        if ((arg1.b & 0xf) != 0 || (arg1 & 0xfff) u< 0x100)
            break
        
        *arg2 = i
        int32_t ecx
        ecx.w = arg1.w & 0xf000
        *arg3 = ecx
        return ((arg1 - ecx - 0x100) s>> 4) + ecx + 8
    
    i = *i
while (i != &data_1bfa0b0)

return 0
