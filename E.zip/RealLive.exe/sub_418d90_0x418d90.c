// 函数: sub_418d90
// 地址: 0x418d90
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
arg1.b = *(entry_ebx + arg1)
undefined
