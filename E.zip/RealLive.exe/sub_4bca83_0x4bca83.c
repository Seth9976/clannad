// 函数: sub_4bca83
// 地址: 0x4bca83
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
*(arg2 + (entry_ebx << 2) + 0x52fdea75)

if (add_overflow(arg1 - 2, neg.d(*(arg2 + (entry_ebx << 2) + 0x52fdea75))))
    undefined

jump(0x4bca8e)
