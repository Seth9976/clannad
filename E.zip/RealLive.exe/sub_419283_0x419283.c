// 函数: sub_419283
// 地址: 0x419283
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ebx = __return_addr | arg3
void arg_4
__return_addr = &arg_4
*(arg2 + 0x74) |= ebx
arg2.b ^= *arg4

if (arg2.b s>= 0)
    int32_t eflags
    __in_oeax_dx(arg2.w, eflags)
    *(0x4e11422f(arg2) - 0x4b262bfb)
    undefined

void* const* var_4_1 = &__return_addr

if ((*arg4 & ebx.b) s< 0)
    arg2:1.b = sbb.b(arg2:1.b, *(arg1 + 0x4ba91ce), false)
    int32_t eax
    eax.b = 0xdb
    int32_t eflags_2
    char temp0_3
    char temp1_2
    temp0_3, temp1_2, eflags_2 = __aam_immb(0xe8, 0xdb)
    eax.b = temp0_3
    eax:1.b = temp1_2
    int32_t* var_8 = arg5
    *arg5 = eax
    undefined

int32_t eflags_1
char temp0
char temp1_1
temp0, temp1_1, eflags_1 = __aam_immb(0xbe, 0xc5)
int32_t eax_3
eax_3.b = temp0
eax_3:1.b = temp1_1
int32_t eax_4 = *arg4
int32_t eax_6
eax_6.b = __in_al_dx(eax_4.w, eflags_1)
int32_t var_4_2 = eax_4
*(arg4 + 4)
undefined
