// 函数: sub_4a0de9
// 地址: 0x4a0de9
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
return __in_oeax_immb(0xcf, eflags)
