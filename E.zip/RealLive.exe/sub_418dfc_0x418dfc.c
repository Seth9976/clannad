// 函数: sub_418dfc
// 地址: 0x418dfc
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
arg1.b = *(entry_ebx + arg1)
undefined
