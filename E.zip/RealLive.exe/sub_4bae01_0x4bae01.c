// 函数: sub_4bae01
// 地址: 0x4bae01
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp1 = *(arg1 + 0x71)
*(arg1 + 0x71) += arg1:1.b
*(arg2 - 0x2a393030) = sbb.b(*(arg2 - 0x2a393030), arg2.b, temp1 + arg1:1.b u< temp1)
*(arg3 + 0x54) ^= ((*(arg4 - 0x20c1e105)).w * 0x7f59):1.b
int32_t ecx
ecx:1.b = 0x98
int16_t ds
arg10 = zx.d(ds)
undefined
