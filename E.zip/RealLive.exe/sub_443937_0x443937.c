// 函数: sub_443937
// 地址: 0x443937
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*(arg2 - 0x275f7cd8) = rrc.d(*(arg2 - 0x275f7cd8), 0x65, c)
int32_t ebx
ebx.b = arg4
void arg_20
*(&arg_20 + (arg1 << 2)) = arg4
*arg3
jump(ebx + 1)
