// 函数: sub_4af8d8
// 地址: 0x4af8d8
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg4 - 0x7b) = arg2
int16_t ss
uint32_t var_4 = zx.d(ss)
*(arg1 - 0x28) |= arg3:1.b
int32_t eflags
arg1.b = __in_al_immb(0x5b, eflags)
*arg5
trap(0x4d)
