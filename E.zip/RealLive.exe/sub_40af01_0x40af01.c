// 函数: sub_40af01
// 地址: 0x40af01
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds = __return_addr.w
*(arg2 - 0x51) = arg1
uint32_t var_2 = zx.d(ds)
int32_t ecx
ecx:1.b = 9
uint32_t var_6 = zx.d(ds)
undefined
