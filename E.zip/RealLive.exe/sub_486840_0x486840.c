// 函数: sub_486840
// 地址: 0x486840
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1
breakpoint
