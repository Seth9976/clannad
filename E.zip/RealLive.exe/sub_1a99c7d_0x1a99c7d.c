// 函数: sub_1a99c7d
// 地址: 0x1a99c7d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t* result = data_1c07710

if (result == 1)
label_1a99c99:
    sub_1a99cb6(0xfc)
    int32_t eax = data_1c078b0
    
    if (eax != 0)
        eax()
    
    result = sub_1a99cb6(0xff)
else if (result == 0 && data_1bf9d64 == 1)
    goto label_1a99c99

return result
