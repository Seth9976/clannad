// 函数: sub_401f0a
// 地址: 0x401f0a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char* entry_ebx
*entry_ebx += arg2
undefined
