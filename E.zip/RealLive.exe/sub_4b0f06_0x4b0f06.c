// 函数: sub_4b0f06
// 地址: 0x4b0f06
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 += arg2
*(arg3 + 0x6c1d753)
int32_t entry_ebx
*(entry_ebx - 1)
undefined
