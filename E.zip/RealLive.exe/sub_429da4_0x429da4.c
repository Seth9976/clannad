// 函数: sub_429da4
// 地址: 0x429da4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

__int1()
int16_t ss
uint32_t var_4 = zx.d(ss)
bool c
void* eax_1 = sbb.d(arg2, *arg1, c)
*(eax_1 + 0x55f9ea02) += eax_1:1.b
int32_t eflags
int32_t eflags_1
char temp0_1
char temp1
temp0_1, temp1, eflags_1 = __aaa(eax_1.b, eax_1:1.b, eflags)
eax_1.b = temp0_1
eax_1:1.b = temp1
*(arg3 + 0x3d)
*arg4
undefined
