// 函数: sub_4bae50
// 地址: 0x4bae50
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
arg1:1.b += __return_addr.w:1.b
int32_t edx
edx:1.b = 0xca
int16_t eax
void* edx_1
eax, edx_1 = 0xcf1b5dbe()
*(edx_1 - 0x49) += eax:1.b
undefined
