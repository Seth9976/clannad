// 函数: sub_4afaad
// 地址: 0x4afaad
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg1 = sbb.b(*arg1, 0xb6, c)
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
undefined
