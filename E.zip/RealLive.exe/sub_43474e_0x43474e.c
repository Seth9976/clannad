// 函数: sub_43474e
// 地址: 0x43474e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1
undefined
