// 函数: sub_46c19a
// 地址: 0x46c19a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg5
int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __daa(arg1, eflags)
int32_t eax = *arg4
int32_t temp1 = *(arg3 + 0x5ce8b754)
*(arg3 + 0x5ce8b754) = ror.d(*(arg3 + 0x5ce8b754), 0xde)
bool c = unimplemented  {ror dword [ecx+0x5ce8b754], 0xde}
bool p = unimplemented  {ror dword [ecx+0x5ce8b754], 0xde}
bool a = unimplemented  {ror dword [ecx+0x5ce8b754], 0xde}
bool o = unimplemented  {ror dword [ecx+0x5ce8b754], 0xde}
int32_t eax_1
eax_1.b = __in_al_dx(eax.w, eflags_1)
int32_t ebx
int32_t var_4 = ebx
bool d
int32_t var_8_1 = (o ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa | (ror.d(temp1, 0xde) s< 0 ? 1 : 0) << 7
    | (ror.d(temp1, 0xde) == 0 ? 1 : 0) << 6 | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (c ? 1 : 0)
*(arg3 - 0x50ac15d4)
int32_t var_8
return sbb.d(eax_1, 0x33be95d0, *(eax_1 + (eax << 3) - 0x97bab72) u< &var_8)
