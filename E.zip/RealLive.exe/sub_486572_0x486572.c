// 函数: sub_486572
// 地址: 0x486572
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 0x4ee57fb0)
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
__out_dx_oeax(0x404, arg1 - 1, eflags_1)
int32_t var_4 = arg1 - 1
int32_t eax
eax.b = *arg3
breakpoint
