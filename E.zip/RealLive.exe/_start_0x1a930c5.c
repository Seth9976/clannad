// 函数: _start
// 地址: 0x1a930c5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

// 无法获取HLIL代码
