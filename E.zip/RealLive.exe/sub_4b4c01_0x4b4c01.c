// 函数: sub_4b4c01
// 地址: 0x4b4c01
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1
undefined
