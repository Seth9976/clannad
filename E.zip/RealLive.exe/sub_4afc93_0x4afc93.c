// 函数: sub_4afc93
// 地址: 0x4afc93
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (arg2 s> 1)
    jump(0x4afc9a)

arg1.b += *(arg2 - 1)
undefined
