// 函数: sub_4b2990
// 地址: 0x4b2990
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t es
uint32_t var_4 = zx.d(es)
__int1()
