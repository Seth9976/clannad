// 函数: sub_486786
// 地址: 0x486786
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp1 = *(arg2 - 0x72)
*(arg2 - 0x72) += arg3.b
*arg6 = *arg5
void* esi = &arg5[1]
*(arg3 + 0xa59d805) = rlc.b(*(arg3 + 0xa59d805), 0xcc, temp1 + arg3.b u< temp1)
int16_t ds
uint32_t var_8 = zx.d(ds)
*(arg6 + 1) = arg4
bool c0
bool c1
bool c2
bool c3
*(esi - 0x2fd7a0dd) =
    (c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe
void* esi_1 = esi - *arg4
int32_t eflags
__out_immb_oeax(0xcf, arg4, eflags)
*(esi_1 - 0x4de67cad)
trap(0x92)
