// 函数: sub_401ef0
// 地址: 0x401ef0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t edx
bool c
edx:1.b = sbb.b((*(arg1 - 0x80)).w:1.b, *(arg3 + 0x4ba91ce), c)
arg1.b += 0x64
int32_t eflags
char temp0
char temp1
temp0, temp1, eflags = __aam_immb(0xe8, arg1.b)
arg1.b = temp0
arg1:1.b = temp1
void** var_4 = arg4
*arg4 = arg1
breakpoint
