// 函数: sub_1a97821
// 地址: 0x1a97821
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 + 0x50) = 0x1bfc3d8
*(arg1 + 0x14) = 1
return arg1
