// 函数: sub_49c9b4
// 地址: 0x49c9b4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

unimplemented  {enter 0x2407, 0x43}
*(arg1 - 0x77)
*(arg2 - 0x75) u>>= 0xf4
trap(0xd)
