// 函数: sub_1a9477d
// 地址: 0x1a9477d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*__builtin_memset(0x1c091e0, 0, 0x100) = 0
data_1c09058 = 0
data_1c090dc = 0
data_1c092e4 = 0
data_1c090d0 = 0
void* edi_2 = &data_1c090d4
*edi_2 = 0
*(edi_2 + 4) = 0
return 0
