// 函数: sub_4a7233
// 地址: 0x4a7233
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg3 = arg1.b
bool s

if (s)
    jump(0x4a7237)

*(arg3 + 1) = arg1
undefined
