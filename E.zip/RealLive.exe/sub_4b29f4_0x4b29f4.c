// 函数: sub_4b29f4
// 地址: 0x4b29f4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
arg1.b = *(entry_ebx + arg1)
bool z

if (z || arg3 != 1)
    bool c
    *(arg4 + 0xd) = rlc.b(*(arg4 + 0xd), (arg3 - 1).b, c)
    arg2.b = *(arg3 + 0xbe94a1)
    trap(0xd)

void arg_4
__return_addr = &arg_4
*(arg4 - 0x3f664ae2) += (*arg5).b
0xc48f6ef1()
undefined
