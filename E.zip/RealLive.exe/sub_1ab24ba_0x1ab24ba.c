// 函数: sub_1ab24ba
// 地址: 0x1ab24ba
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t result = LoadStringA(*(sub_1ac597f() + 0xc), arg1, arg2, arg3)

if (result == 0)
    *arg2 &= result.b

return result
