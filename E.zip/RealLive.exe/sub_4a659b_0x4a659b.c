// 函数: sub_4a659b
// 地址: 0x4a659b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* ecx = *(arg1 - 0x13dc7bac) * 0xffffffc8
int32_t eflags
int32_t eax
eax.b = __in_al_dx(arg2.w, eflags)
int32_t ebx
int32_t var_4 = ebx
uint8_t* edi
uint8_t temp0_2
temp0_2, edi = __insb(arg3, arg2.w, eflags)
*edi = temp0_2
*(ecx + 0x488d0cd9)
int32_t eax_1 = eax ^ 0x78f93d6a
int32_t* esi = __outsd(arg2.w, *0xd09f8410, 0xd09f8410, eflags)
uint8_t* var_9 = edi

if (eax_1 s>= 0)
    *edi
    undefined

eax_1.b |= 0xb2

if (eax_1.b u< 0)
    void* var_d_1 = arg1
    *edi
    undefined

int32_t var_d = eax_1
void* var_11 = ecx
void* var_15 = arg2
int32_t var_19 = ebx
int32_t* var_1d = &var_19
void* var_21 = arg1
int32_t* var_25 = esi
int16_t var_29 = edi.w
int32_t eflags_1
char temp0_3
temp0_3, eflags_1 = __das(eax_1.b, eflags)
eax_1.b = temp0_3
unimplemented  {enter 0x53ce, 0xbe}
*(arg2 - 0x6e7df271)
__cli(eflags_1)
void* var_2b = ecx
*eax_1
undefined
