// 函数: sub_439ea0
// 地址: 0x439ea0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0x1cce3052) = rol.b(*(arg2 + 0x1cce3052), 1)
*(arg3 + arg2 + 0x30) = rol.d(*(arg3 + arg2 + 0x30), 1)
int32_t eflags
__out_immb_oeax(0x7c, arg1, eflags)
*(arg4 + 0x43f4f4e4) -= 1
*arg5
undefined
