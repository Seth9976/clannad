// 函数: sub_4a0de4
// 地址: 0x4a0de4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 -= 1
undefined
