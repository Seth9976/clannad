// 函数: sub_418d81
// 地址: 0x418d81
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__in_oeax_dx(arg2, eflags)
int32_t ebx
int32_t var_4 = ebx
*arg3
undefined
