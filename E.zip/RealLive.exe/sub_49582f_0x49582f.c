// 函数: sub_49582f
// 地址: 0x49582f
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
*arg3 = arg1
*(arg2 - 0x2fd6abcf)
uint32_t* var_8 = &var_4
arg3[1]
undefined
