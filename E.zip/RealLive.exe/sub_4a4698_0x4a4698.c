// 函数: sub_4a4698
// 地址: 0x4a4698
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*(arg2 + 0x5c2a54c3) = rrc.d(*(arg2 + 0x5c2a54c3), 1, c)
int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __daa(arg1.b, eflags)
arg1.b = temp0
int32_t eflags_2 = __cli(eflags_1)
void* edx_1
edx_1.b = (arg2 - 2).b * 2
bool c_1 = *arg4 u< *arg5
void* esi = &arg4[1]
int32_t entry_ebx
*(arg1 - 4) = entry_ebx
void* esi_1 = __outsd(edx_1.w, *esi, esi, eflags_2)
long double x87_r0 = fconvert.t(*(esi_1 + edx_1 - 0x32)) / arg6
int16_t ds
*(arg1 - 8) = zx.d(ds)
edx_1.b = 0x89
*(esi_1 - 0x2fd5bb4e) = int.q(x87_r0)
arg3:1.b = adc.b(arg3:1.b, (arg5.w + 1):1.b, c_1 ^ 1)
undefined
