// 函数: sub_4b0f13
// 地址: 0x4b0f13
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
long double result = float.t(*(arg3 - 0x2fd4f15d)) / arg4
*(&var_4 - arg1)
void* esp
*(esp + 4)
int32_t eflags
arg1.b = __in_al_immb(0xcf, eflags)
arg2.b = arg2:1.b
return result
