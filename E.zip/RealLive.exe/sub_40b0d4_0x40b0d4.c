// 函数: sub_40b0d4
// 地址: 0x40b0d4
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 - 0x42e973a4) = rol.b(*(arg1 - 0x42e973a4), 1)
