// 函数: sub_4b1673
// 地址: 0x4b1673
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg1 = sbb.b(*arg1, 0xb3, c)
breakpoint
