// 函数: sub_48681c
// 地址: 0x48681c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4de67cad) = int.w(arg4)
trap(0x92)
