// 函数: sub_4bcae5
// 地址: 0x4bcae5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return arg1 ^ 0x80502454
