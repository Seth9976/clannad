// 函数: sub_4bae6c
// 地址: 0x4bae6c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ebp
int32_t var_4 = ebp
int32_t eflags
__outsd(arg2, *arg3, arg3, eflags)
int32_t* var_8 = &var_4
*arg4
undefined
