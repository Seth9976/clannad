// 函数: sub_40b0cc
// 地址: 0x40b0cc
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 |= arg3
int32_t var_4 = 0xa75be4d8
undefined
