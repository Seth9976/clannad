// 函数: sub_439e01
// 地址: 0x439e01
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c = *arg4 u< *arg5
void* esi = &arg4[1]
void* edi = &arg5[1]
int16_t eax = (*esi).w
void* esi_1 = esi + 4
int32_t eflags
int32_t eflags_1
char temp0
char temp1
temp0, temp1, eflags_1 = __aaa(eax.b, eax:1.b, eflags)
eax.b = temp0
eax:1.b = temp1
*edi = *(esi_1 + 1)
void* edi_1 = edi + 1
void* esi_3 = esi_1 + 2
int32_t eflags_2
char temp0_1
temp0_1, eflags_2 = __daa(eax.b, eflags_1)
eax.b = temp0_1
int32_t entry_ebx

if (arg3 != 1 && not(c))
    *arg2 = adc.b(*arg2, entry_ebx:1.b, c)
    int16_t var_34[0x16]
    es
    var_34[arg1 * 4] = es
    int32_t var_4_1 = entry_ebx
    *edi_1
    void* edi_2 = edi_1 + 4
    *esi_3 - *edi_2
    *(edi_2 + 4)
    jump(0x439ec6)

int32_t var_4 = entry_ebx

if (arg3 - 1 s< 0 == add_overflow(arg3, 0xffffffff))
    return sub_439e42(arg3 - 1, edi_1) __tailcall

*edi_1 = *esi_3
int16_t ds
uint32_t var_8 = zx.d(ds)
arg1:1.b = 0xa0
entry_ebx:1.b = 0x33
*(&var_8 + ((edi_1 + 1) << 1))
int16_t eax_1
eax_1:1.b = (eax - 1):1.b u>> 0x53
undefined
