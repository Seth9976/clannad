// 函数: sub_4866b8
// 地址: 0x4866b8
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x7b) = arg2
int32_t eax
eax:1.b = 0xcb
bool c
*arg1 = adc.d(*arg1, arg1, c)
int32_t eflags
__out_immb_oeax(0xcf, &__return_addr:2, eflags)
*0x2feb0000 = *arg4
undefined
