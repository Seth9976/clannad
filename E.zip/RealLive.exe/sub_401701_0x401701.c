// 函数: sub_401701
// 地址: 0x401701
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t x87status
uint224_t temp0_1
temp0_1, x87status = __fnstenv_memmem28()
*(arg1 + 0xdb99da) = temp0_1
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
__out_dx_oeax(arg5, arg3, eflags_1)
undefined
