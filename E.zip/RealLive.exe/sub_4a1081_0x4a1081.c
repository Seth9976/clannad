// 函数: sub_4a1081
// 地址: 0x4a1081
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 0x63) <<= 1
undefined
