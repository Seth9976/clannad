// 函数: sub_47031d
// 地址: 0x47031d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
bool c
entry_ebx.b = adc.b(entry_ebx.b, arg1:1.b, c)
arg1.b = *arg2
unimplemented  {enter 0xae67, 0xba}
int32_t var_4 = entry_ebx
trap(0x70)
