// 函数: sub_4b6d86
// 地址: 0x4b6d86
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x17ac5845) += arg2
*0x3805d806 = arg1
undefined
