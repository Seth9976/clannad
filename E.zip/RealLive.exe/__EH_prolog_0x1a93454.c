// 函数: __EH_prolog
// 地址: 0x1a93454
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t var_4 = 0xffffffff
int32_t eax
int32_t var_8 = eax
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
void* const result = __return_addr
fsbase->NtTib.ExceptionList = &ExceptionList
void* __return_addr_1
__return_addr = __return_addr_1
return result
