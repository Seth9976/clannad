// 函数: sub_4a728d
// 地址: 0x4a728d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg1 = sbb.b(*arg1, 0xb7, c)
*arg2
undefined
