// 函数: sub_1a9371d
// 地址: 0x1a9371d
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

uint32_t ecx
ecx.b = *(zx.d(*arg1) + 0x1c091e1)
ecx.b &= 4
void* result = &arg1[1]

if (ecx.b == 0)
    return result

return result + 1
