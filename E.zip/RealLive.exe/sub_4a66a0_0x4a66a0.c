// 函数: sub_4a66a0
// 地址: 0x4a66a0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 += arg1.b
void* entry_ebx
*(entry_ebx - 0x14) = arg3
void* var_4 = entry_ebx
*arg3
undefined
