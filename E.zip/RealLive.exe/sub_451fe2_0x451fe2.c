// 函数: sub_451fe2
// 地址: 0x451fe2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t edx_1
int16_t es
edx_1, es = __les_gprz_memp(*(arg1 + 0x15))
char* var_4 = arg2
*arg2
*arg3
undefined
