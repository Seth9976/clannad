// 函数: sub_4125d6
// 地址: 0x4125d6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 + (arg1 << 2) + 0x1f) = arg2
arg1:1.b = 0xcb
int32_t eflags
__out_dx_al(arg2.w, arg3.b, eflags)
*arg4
trap(0x4f)
