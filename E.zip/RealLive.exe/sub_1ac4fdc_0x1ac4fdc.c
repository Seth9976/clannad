// 函数: sub_1ac4fdc
// 地址: 0x1ac4fdc
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1[1] + arg2) = *arg1
*arg1 = arg2
return arg2
