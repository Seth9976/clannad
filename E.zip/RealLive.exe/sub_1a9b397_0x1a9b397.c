// 函数: sub_1a9b397
// 地址: 0x1a9b397
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1a9b3ae(arg1, arg2, arg3, 0)
