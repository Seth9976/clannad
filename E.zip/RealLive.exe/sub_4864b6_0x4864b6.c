// 函数: sub_4864b6
// 地址: 0x4864b6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t entry_ebx
*(arg2 - 0x4d) += entry_ebx:1.b
*arg5 = *arg4
void* edi = &arg5[1]
int32_t var_4 = entry_ebx
int16_t ds
uint32_t var_8 = zx.d(ds)
int16_t edx = (adc.d(arg2, *(edi + 0x63c7bedd), arg3 u>= 0x33f65f28)).w
int32_t eax_1
eax_1.b = (arg3 - 0x33f65f28).b - edx.b
int32_t eflags
eax_1.b = __in_al_dx(edx, eflags)
int32_t var_c = entry_ebx
*edi = eax_1
undefined
