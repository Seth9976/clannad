// 函数: sub_1a9c64e
// 地址: 0x1a9c64e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return sub_1a9c697(arg1, 0, 4)
