// 函数: sub_495821
// 地址: 0x495821
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg2 = *arg1
int32_t eax
eax.b = 0xdd
undefined
