// 函数: sub_46cc0e
// 地址: 0x46cc0e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

char temp1 = *arg1
*arg1 += arg1:1.b
arg1:1.b = adc.b(arg1:1.b, *(arg2 + 0xb0df253), temp1 + arg1:1.b u< temp1)
return arg4 / arg5
