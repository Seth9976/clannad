// 函数: sub_1a97647
// 地址: 0x1a97647
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

InitializeCriticalSection(data_1bfc11c)
InitializeCriticalSection(data_1bfc10c)
InitializeCriticalSection(data_1bfc0fc)
return InitializeCriticalSection(data_1bfc0dc)
