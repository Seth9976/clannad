// 函数: sub_47039a
// 地址: 0x47039a
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 - 0x2f) += arg1:1.b
int32_t eflags
__out_dx_al(arg2, arg1.b, eflags)
void** var_4 = arg3 + 1
*(arg3 + 1) = arg1
undefined
