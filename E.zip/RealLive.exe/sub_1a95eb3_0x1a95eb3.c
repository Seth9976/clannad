// 函数: sub_1a95eb3
// 地址: 0x1a95eb3
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t result = HeapAlloc(data_1c09030, HEAP_NONE, 0x140)
data_1c09028 = result

if (result == 0)
    return result

data_1c09020 = 0
data_1c09024 = 0
data_1c09018 = result
data_1c0902c = arg1
data_1c09000 = 0x10
return 1
