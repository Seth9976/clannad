// 函数: sub_1a91f33
// 地址: 0x1a91f33
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(9)
