// 函数: sub_4a0dd9
// 地址: 0x4a0dd9
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*arg1 = 0xce5c4fd8
int16_t ds
uint32_t var_4 = zx.d(ds)
