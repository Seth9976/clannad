// 函数: sub_4a46be
// 地址: 0x4a46be
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return 
