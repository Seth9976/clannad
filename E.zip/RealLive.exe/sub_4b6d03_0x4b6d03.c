// 函数: sub_4b6d03
// 地址: 0x4b6d03
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
*arg1 -= 0xd02b62af
int32_t eflags
int32_t eax
eax.b = __in_al_immb(0xcf, eflags)
int32_t eax_1
int32_t edx
edx:eax_1 = sx.q(eax)
int32_t entry_ebx
*(arg1 - 0x7dac584d) += (entry_ebx.w - 1).b
*arg3 = eax_1
int16_t es
uint32_t var_8 = zx.d(es)
int16_t ebx
ebx:1.b = (entry_ebx.w - 1):1.b ^ arg1.b
uint32_t var_c = zx.d(ds)
*0xd02b62af = 0xd02b62af
int32_t eax_2
eax_2.b = __in_al_immb(0xcf, eflags)
__out_immb_oeax(0xbd, eax_2, eflags)
return arg5 / arg4
