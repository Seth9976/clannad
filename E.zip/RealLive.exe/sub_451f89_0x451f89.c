// 函数: sub_451f89
// 地址: 0x451f89
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

__int1()
int32_t eflags
int16_t* edi
int16_t temp0
temp0, edi = __insd(arg3, arg2, eflags)
*edi = temp0
bool c
return sbb.d(arg1, 0x1e845bb9, c)
