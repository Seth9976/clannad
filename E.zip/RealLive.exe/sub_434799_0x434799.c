// 函数: sub_434799
// 地址: 0x434799
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
float* eax
bool c
eax.b = __in_al_dx(
    (sbb.d(arg2, arg3, 
        adc.d(arg1, 0xac0d94ba, c) u< arg1 || (c && adc.d(arg1, 0xac0d94ba, c) == arg1))).w, 
    eflags)
bool c_1 = arg4 u< arg3
*eax
__out_immb_al(0x44, eax.b, eflags)
int16_t ds
uint32_t var_8 = zx.d(ds)
arg3:1.b = 0xca
eax.b = sbb.b(eax.b, 0xc, c_1)
breakpoint
