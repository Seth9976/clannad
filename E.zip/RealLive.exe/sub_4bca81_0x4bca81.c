// 函数: sub_4bca81
// 地址: 0x4bca81
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__out_immb_oeax(0x37, arg1, eflags)
int32_t entry_ebx
*(entry_ebx + 0x35c5eaf7)
*(arg1 - 0x78) += arg2
int16_t x87status
uint224_t temp0
temp0, x87status = __fnstenv_memmem28()
*(arg3 - 0x76b3af53) = temp0
unimplemented  {enter 0x6100, 0x64}
undefined
