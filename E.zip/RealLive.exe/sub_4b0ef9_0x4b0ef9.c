// 函数: sub_4b0ef9
// 地址: 0x4b0ef9
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
void* result
result.b = __in_al_immb(0xcf, eflags)
bool c

if (not(c))
    return result

arg1:1.b = adc.b(arg1:1.b, *(result + (arg2 << 1) + 0x60d4894c), c)

if (arg1:1.b != 0)
    jump(0x4b0edd)

*(arg1 - 0x77)
int16_t* edi = adc.d(arg3, *(result + 0xdb398c7), false)
*0x84d540c2 = result.b | 0x6d
int32_t* entry_ebx
*entry_ebx = arg2
*0x84d540c2 = 0xef
*entry_ebx = arg2
*0x8fdd49c2 = 0xef
int32_t* arg_8 = entry_ebx
int16_t ss
*edi = ss
*0x84d540c2 = 0xef
*entry_ebx = arg2
*0x84d540c2 = 0xef
*entry_ebx = arg2
*0x84d540c2 = 0xef
*entry_ebx = arg2
*0x84d540c2 = 0xef
*entry_ebx = arg2
*0x84d540c2 = 0xef
*entry_ebx = arg2
undefined
