// 函数: sub_424015
// 地址: 0x424015
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
char entry_ebx
char temp0
temp0, eflags_1 = __daa(arg1 * entry_ebx, eflags)
int32_t var_4 = 0x41
breakpoint
