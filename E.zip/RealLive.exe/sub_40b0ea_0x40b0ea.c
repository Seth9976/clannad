// 函数: sub_40b0ea
// 地址: 0x40b0ea
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ss
*arg4 = ss
*(arg1 - 0x28) |= arg3:1.b
int32_t eflags
arg1.b = __in_al_immb(0x5b, eflags)
*arg4 - *arg5
void* esi = &arg4[2]
int32_t edi = arg5 + 4
*0x8b69d92 = 0x168c5c81
int16_t es
uint32_t var_4 = zx.d(es)
int32_t var_8 = 0xa75be4d8
*0x8b69d92 = 0x168c5c81
*(arg1 - 0x28) |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi - *edi
void* esi_1 = esi + 4
int32_t edi_1 = edi + 4
*0x8b69d92 = 0x168c5c81
*(arg1 - 0x28) |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*esi_1 - *edi_1
*0x8b69d92 = 0x168c5c81
*(arg1 - 0x28) |= arg3:1.b
arg1.b = __in_al_immb(0x5b, eflags)
*(esi_1 + 4) - *(edi_1 + 4)
*0x8b69d92 = 0x8e145381
undefined
