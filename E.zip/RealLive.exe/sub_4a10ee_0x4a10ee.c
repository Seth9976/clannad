// 函数: sub_4a10ee
// 地址: 0x4a10ee
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t ecx
ecx.b = 0xeb
*arg1
undefined
