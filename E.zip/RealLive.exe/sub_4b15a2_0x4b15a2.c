// 函数: sub_4b15a2
// 地址: 0x4b15a2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*0x2953a7c4 += arg3
float.t(*arg4) - fconvert.t(*arg4)
undefined
