// 函数: sub_4a1098
// 地址: 0x4a1098
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg7 f- arg8
__punpckldq_mmxq_memd(arg6, *(arg1 - 0x4a5de116))
int32_t var_4 = arg5
arg2[0x1118763b].b <<= 0xe1
*(arg3 - 1)
*arg4
*(arg2 + 0x6d) -= arg5:1.b
*arg2
undefined
