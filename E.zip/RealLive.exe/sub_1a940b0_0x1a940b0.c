// 函数: sub_1a940b0
// 地址: 0x1a940b0
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

if (arg1 != 0)
    void* eax_3 = sub_1a91fb2(sub_1a91a20(arg1) + 1)
    
    if (eax_3 != 0)
        return sub_1a91830(eax_3, arg1)

return 0
