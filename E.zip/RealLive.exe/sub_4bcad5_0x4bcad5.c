// 函数: sub_4bcad5
// 地址: 0x4bcad5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg2 = rrc.d(*arg2, 0xd0, c)
int32_t eax
int32_t* ecx
int32_t edx
return sub_4bcb49(eax, edx, ecx, arg1 - 1, arg2) __tailcall
