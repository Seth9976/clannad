// 函数: sub_4125c2
// 地址: 0x4125c2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 + 0x67)
int16_t x87control
int16_t x87status
int16_t x87tag
uint864_t temp0
temp0, x87control, x87tag, x87status = __fnsave_memmem108(arg4, arg6, arg5)
*(arg1 - 0x11) = temp0
int32_t eflags
char temp0_1
char temp1
temp0_1, temp1, eflags = __aam_immb(0xbe, arg1.b)
arg1.b = temp0_1
arg1:1.b = temp1
bool c

if (&__return_addr == 0xffffffff || c)
    undefined

undefined
