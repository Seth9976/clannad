// 函数: sub_49578b
// 地址: 0x49578b
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg2 - 4)
undefined
