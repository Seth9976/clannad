// 函数: sub_1a9a360
// 地址: 0x1a9a360
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(9)
