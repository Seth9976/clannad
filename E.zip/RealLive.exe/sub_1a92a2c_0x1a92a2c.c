// 函数: sub_1a92a2c
// 地址: 0x1a92a2c
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

for (int32_t* i = arg1; i u< arg2; i = &i[1])
    int32_t eax = *i
    
    if (eax != 0)
        eax()
