// 函数: sub_4be5a6
// 地址: 0x4be5a6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
char entry_ebx
arg3:1.b &= entry_ebx
*arg2 += __return_addr.b
__return_addr = arg2
*arg4
undefined
