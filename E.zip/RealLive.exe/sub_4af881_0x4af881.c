// 函数: sub_4af881
// 地址: 0x4af881
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__out_dx_oeax(arg2 - 1, arg1, eflags)
int32_t var_4 = arg1
*(arg3 + 0x3f) += (arg2 - 2):1.b
*arg4 - *arg5
void* esi = arg4 + 1
char* edi = arg5 + 1
float* entry_ebx
int16_t var_8 = entry_ebx.w
*edi &= arg1.b
long double result = arg6 - fconvert.t(*entry_ebx)
*esi - *edi
char* esi_1 = esi + 1
void* edi_1 = &edi[1]
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
int32_t ecx
ecx:1.b = 0xcb
void* eax
char* edx_1
edx_1:eax = sx.q(arg1)
edx_1.b = 0xc
char temp1 = eax:1.b
eax:1.b += entry_ebx[-0xb].b

if (temp1 == neg.b(entry_ebx[-0xb].b) || ecx == 1)
    *edi_1 = eax.b
    *arg3
    int32_t eflags_2
    char temp0
    char temp1_1
    temp0, temp1_1, eflags_2 = __aam_immb(0x85, eax.b)
    eax.b = temp0
    eax:1.b = temp1_1
    arg3[1]
    *edx_1 = 0xc
    int16_t ecx_2
    ecx_2:1.b = *(entry_ebx - 0x25)
    int32_t eax_1
    eax_1.b = *esi_1
    
    if (ecx_2:1.b s>= 0)
        return result
    
    arg3[2].w
    *(esi_1 + 1) - *(edi_1 + 1)
    int32_t eflags_3
    int32_t eip_1
    eip_1, eflags_3 = __into(eflags_2)
    *(arg3 + 6) = zx.d(var_8)
    void* eax_2 = __in_oeax_dx(edx_1.w, eflags_3)
    *(eax_2 + 0x2c0dcfe5) = adc.b(*(eax_2 + 0x2c0dcfe5), eax_2:1.b, entry_ebx:1.b u< entry_ebx.b)
    return result - arg7

int16_t ss
*esi_1 = ss
int32_t esp_5 = zx.d(var_8) i+ entry_ebx[-0xa]
eax.b = __in_al_immb(0x5b, eflags_1)
*esi_1 - *edi_1
void* esi_5 = &esi_1[4]
void* edi_4 = edi_1 + 4
*0x3b69d92 = 0x168c5c81
*(entry_ebx - 0x2d) |= eax:1.b
eax.b = __in_al_immb(0x5b, eflags_1)
*esi_5 - *edi_4
void* edi_5 = edi_4 + 4
*0x8b69d92 = 0x168c5c81
*(eax - 0x28) |= (ecx - 1):1.b
__out_dx_oeax(edx_1.w, eax, eflags_1)
*(esp_5 - 4) = eax
*(esi_5 + 4) - *edi_5
*0x8b69d92 = 0x168c5c81
*(eax - 0x28) |= (ecx - 1):1.b
eax.b = __in_al_immb(0x5b, eflags_1)
*(edi_5 + 4) = eax
undefined
