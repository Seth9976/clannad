// 函数: sub_4779be
// 地址: 0x4779be
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg5 - fconvert.t(*(arg4 + (arg3 << 2) - 0x31))
*arg2 = arg1
*(arg1 + 0x18cab51b)
int32_t cs
*(cs + &data_1bdd060) += arg1.b
jump(*arg4)
