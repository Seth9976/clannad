// 函数: sub_4a0def
// 地址: 0x4a0def
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t var_4 = &__return_addr
int32_t eflags
__out_dx_oeax(arg2.w, arg1, eflags)
undefined
