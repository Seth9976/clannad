// 函数: sub_495781
// 地址: 0x495781
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eflags
__outsb(arg2, *arg3, arg3, eflags)
int16_t eax
eax:1.b = (arg1 + 1):1.b + arg2:1.b
undefined
