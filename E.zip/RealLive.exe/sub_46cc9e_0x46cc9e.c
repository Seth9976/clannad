// 函数: sub_46cc9e
// 地址: 0x46cc9e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b += 4
int32_t eflags
char temp0
char temp1
temp0, temp1, eflags = __aam_immb(0xe8, arg1.b)
arg1.b = temp0
arg1:1.b = temp1
int32_t* var_4 = arg2
*arg2 = arg1
undefined
