// 函数: sub_1a92a23
// 地址: 0x1a92a23
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

return __unlock(0xd)
