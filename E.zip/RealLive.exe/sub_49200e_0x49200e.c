// 函数: sub_49200e
// 地址: 0x49200e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int16_t ds
uint32_t var_4 = zx.d(ds)
breakpoint
