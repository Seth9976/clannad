// 函数: sub_418daf
// 地址: 0x418daf
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

int32_t eax
int32_t entry_ebx
eax.b = entry_ebx.b
int16_t es
int16_t var_4 = es
int32_t eflags
uint8_t* edi
uint8_t temp0
temp0, edi = __insb(arg5, arg2, eflags)
*edi = temp0
*(arg4 - 0x13) = edi - 1
int32_t var_6 = entry_ebx
*(edi - 1)
undefined
