// 函数: sub_1ac5035
// 地址: 0x1ac5035
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

HLOCAL result
int32_t ecx
result, ecx = LocalAlloc(LMEM_ZEROINIT, arg1)

if (result != 0)
    return result

sub_1aab087(ecx)
noreturn
