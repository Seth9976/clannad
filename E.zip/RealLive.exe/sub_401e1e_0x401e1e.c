// 函数: sub_401e1e
// 地址: 0x401e1e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg1.b = 0xae
int32_t var_4 = arg1
int32_t var_8 = arg2
int32_t entry_ebx
char* ss
bool c
ss[entry_ebx] = adc.b(ss[entry_ebx], 0x46, c)
int32_t* temp0 = *(arg5 + arg3 - 0x20f52928)
*(arg5 + arg3 - 0x20f52928) = arg3
*(temp0 + 0x40a606ca)
arg4[0xffffffc9] -= 0x52
int32_t eax
eax.b = *arg4
int32_t var_c = entry_ebx
*temp0
int32_t eflags
eax.b = __salc(eflags)
int16_t ds
*temp0 = zx.d(ds)
*temp0
arg1:1.b = rlc.b(arg1:1.b, 0xae, false)
char temp0_2 = __in_al_dx(arg2.w, eflags)
*(temp0 - 2) = arg2
*arg5 = temp0_2
undefined
