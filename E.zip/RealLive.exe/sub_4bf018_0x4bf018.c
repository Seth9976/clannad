// 函数: sub_4bf018
// 地址: 0x4bf018
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg1 - 0x15) &= arg2.b
int32_t entry_ebx
*(entry_ebx + (arg3 << 2) + 0x27b3f831) s>>= 1
*(arg1 - 0x37f9086c)
arg2.b |= *(arg1 - 0x37f9086c)
int32_t eflags
int16_t eax
eax.b = __in_al_dx(arg2.w, eflags)
*(arg3 - 0x61) = rlc.b(*(arg3 - 0x61), 1, false)
*arg3
*__return_addr
*0x6efc50a1
eax.b ^= eax:1.b
int32_t ecx
ecx.b = 0x84
jump(*(ecx + 0xffffffd0))
