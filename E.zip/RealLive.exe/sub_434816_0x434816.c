// 函数: sub_434816
// 地址: 0x434816
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool p = unimplemented  {or eax, 0xd5489d8}
bool a = undefined
bool d
int32_t var_4 = (d ? 1 : 0) << 0xa | ((arg1 | 0xd5489d8) s< 0 ? 1 : 0) << 7
    | ((arg1 | 0xd5489d8) == 0 ? 1 : 0) << 6 | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2
undefined
