// 函数: sub_4615c5
// 地址: 0x4615c5
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* eax = arg1 & 0xbe91ee
void* edx
edx:1.b = adc.b((&(&__return_addr)[arg1] - 0x69):1.b, arg3:1.b, false)
void* entry_ebx
void* var_4 = entry_ebx
*arg5
int32_t edi = arg5 + 4
*(eax - 0x76) = int.q(arg6)
bool c1 = unimplemented  {fisttp qword [eax-0x76], st0}
void* var_7 = &var_4:1
*(edi - 0x416995c3)
*(entry_ebx + 0x53ef44e8) += arg3.b

do
    *edi
    edi += 4
    arg4 += 1
    bool c0
    bool c2
    bool c3
    *(edx + (arg3 << 2) + 0x54) =
        (c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe | 0x1000
while ((*(eax + 0xbe9652) & edx.b) s< 0)

void* var_b = entry_ebx
*edi
int32_t edi_1 = edi + 4
int32_t eax_1
int16_t ds
eax_1, ds = __lds_gprz_memp(*(edx + (arg3 << 2) + 0x54))
*(arg4 - 0x416999db)
*(arg3 + 0x53ef60e8) += arg3.b
*edi_1
eax_1.b |= 0xdd
int32_t eax_2
eax_2.b = *(entry_ebx + eax_1 - 1)

if (arg3 == 1)
    jump(0x461614)

*(arg3 - 0x172c40ad)
entry_ebx:1.b = 0xa6
int32_t edi_3 = (edi_1 + 4) ^ *((arg3 - 1) * 3)
int32_t eax_4 = *0x5678e837
*(eax_4 + (entry_ebx << 1)) &= eax_4
*(edi_3 + 0x38)
undefined
