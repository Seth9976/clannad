// 函数: sub_46c1c2
// 地址: 0x46c1c2
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg4 + (arg3 << 2) - 0x18) = arg2
int32_t entry_ebx
*(entry_ebx - 0x6f17ff42)
undefined
