// 函数: sub_44f3d6
// 地址: 0x44f3d6
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* entry_ebx
*(entry_ebx + 0x3c) += arg1
int32_t eflags
__sti(eflags)
*(arg2 - 0x3ae13f48)
int32_t es
*(es + arg3 - 0x2fdb1244) s>>= 1
trap(0x54)
