// 函数: sub_1a95efb
// 地址: 0x1a95efb
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

void* result = data_1c09028
void* ecx_1 = result + data_1c09024 * 0x14

while (true)
    if (result u>= ecx_1)
        return nullptr
    
    if (arg1 - *(result + 0xc) u< 0x100000)
        break
    
    result += 0x14

return result
