// 函数: sub_4a4618
// 地址: 0x4a4618
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

arg4 - fconvert.t(*arg1)
int32_t var_2 = 0xffffffce
int16_t ds
uint32_t var_6 = zx.d(ds)
unimplemented  {sbb esp, esi}
*(arg3 - arg1 - 0x2fd5c140) = int.q(arg4)
*(arg2 - 0x1b)
undefined
