// 函数: sub_470393
// 地址: 0x470393
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

bool c
*arg1 = sbb.b(*arg1, 0xf2, c)
undefined
