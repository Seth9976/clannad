// 函数: sub_4b15de
// 地址: 0x4b15de
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 - 0x4de67cad) = int.w(arg4)
trap(0x92)
