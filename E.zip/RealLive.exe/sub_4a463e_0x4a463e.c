// 函数: sub_4a463e
// 地址: 0x4a463e
// 来自: F:\SETUPDATA\GAMEDATA\RealLive.exe

*(arg3 + 0x6a)
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
int16_t ds
uint32_t var_2 = zx.d(ds)
trap(0xd)
