// 函数: __ehhandler$?_FullAliasWait@_TaskCollection@details@Concurrency@@AAEXPAV123@@Z
// 地址: 0x6057b2
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_5f02dd(*(arg1 - 0x24) ^ (arg1 + 0xc))
return sub_5f6f47(0x62a144) __tailcall
