// 函数: ___crtExitProcess
// 地址: 0x5f2fc0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax
HMODULE ecx
int32_t edx
___crtCorExitProcess(eax, edx, ecx, arg1)
ExitProcess(arg1)
noreturn
