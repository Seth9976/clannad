// 函数: $LN24
// 地址: 0x5f4f85
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __unlock_file2(arg1, *(data_20f44e0 + (arg1 << 2)))
