// 函数: ?CPtoLocaleName@@YAPB_WH@Z
// 地址: 0x5f736f
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 == 0x3a4)
    return u"ja-JP"

if (arg1 == 0x3a8)
    return u"zh-CN"

if (arg1 == 0x3b5)
    return u"ko-KR"

if (arg1 == 0x3b6)
    return u"zh-TW"

return 0
