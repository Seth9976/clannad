// 函数: __callnewh
// 地址: 0x5f3e0d
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax = DecodePointer(data_640ff0)

if (eax != 0 && eax(arg1) != 0)
    return 1

return 0
