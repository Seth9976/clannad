// 函数: sub_40e000
// 地址: 0x40e000
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return **arg1 - **arg2
