// 函数: __initp_misc_purevirt
// 地址: 0x5f3e33
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_640ff0 = arg1
return arg1
