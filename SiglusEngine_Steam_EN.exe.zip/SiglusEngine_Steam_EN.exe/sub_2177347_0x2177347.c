// 函数: sub_2177347
// 地址: 0x2177347
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

void* var_4 = sub_2177347 + (*0xa4a70592 ^ 0xaf4f88a2)
return arg1
