// 函数: __cfltcvt_init
// 地址: 0x5f21b8
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_63c5d4 = __cropzeros
data_63c5d0 = __cfltcvt
data_63c5d8 = __fassign
data_63c5dc = __forcdecpt
data_63c5e0 = __positive
data_63c5e4 = __cfltcvt
data_63c5e8 = __cfltcvt_l
data_63c5ec = __fassign_l
data_63c5f0 = __cropzeros_l
data_63c5f4 = __forcdecpt_l
return __cfltcvt
