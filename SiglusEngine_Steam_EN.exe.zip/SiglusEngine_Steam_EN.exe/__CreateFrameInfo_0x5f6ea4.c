// 函数: __CreateFrameInfo
// 地址: 0x5f6ea4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

*arg1 = arg2
arg1[1] = __getptd()[0x26]
__getptd()[0x26] = arg1
return arg1
