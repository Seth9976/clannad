// 函数: ?Release@?$COMRefPtr@VIDebugSSectionReader@@@@AAEXXZ
// 地址: 0x4d9450
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t* ecx = *arg1

if (ecx != 0)
    (*(*ecx + 8))(ecx)
