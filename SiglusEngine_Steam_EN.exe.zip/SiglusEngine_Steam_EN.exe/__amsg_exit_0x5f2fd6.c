// 函数: __amsg_exit
// 地址: 0x5f2fd6
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

__FF_MSGBANNER()
__NMSG_WRITE(arg1)
__exit(0xff)
noreturn
