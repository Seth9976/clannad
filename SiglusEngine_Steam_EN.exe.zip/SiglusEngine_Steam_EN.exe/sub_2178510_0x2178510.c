// 函数: sub_2178510
// 地址: 0x2178510
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

void* ecx = arg1
int32_t i_1 = arg3

if (i_1 != 0)
    int32_t i
    
    do
        char edx = *(arg2 - arg1 + ecx)
        ecx += 1
        *(ecx - 1) = edx
        i = i_1
        i_1 -= 1
    while (i != 1)

return arg1
