// 函数: j_sub_5fbd9b
// 地址: 0x5fbaee
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_5fbd9b() __tailcall
