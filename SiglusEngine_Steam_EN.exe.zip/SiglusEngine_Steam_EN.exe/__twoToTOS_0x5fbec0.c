// 函数: __twoToTOS
// 地址: 0x5fbec0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

long double result = roundint.t(arg1)
__fscale(__f2xm1(fneg(result - arg1)) + float.t(1), result)
return result
