// 函数: $LN11
// 地址: 0x5f95ba
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __unlock(0xc)
