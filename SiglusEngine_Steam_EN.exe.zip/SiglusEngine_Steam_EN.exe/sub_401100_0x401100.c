// 函数: sub_401100
// 地址: 0x401100
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t result = sub_401150(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)

if (result != 0)
    return result

return sub_4014f0(arg2)
