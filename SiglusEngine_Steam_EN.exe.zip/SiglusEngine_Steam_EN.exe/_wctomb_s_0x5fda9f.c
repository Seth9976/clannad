// 函数: _wctomb_s
// 地址: 0x5fda9f
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t var_8 = 0
return __wctomb_s_l(arg1, arg2, arg3, arg4)
