// 函数: __invalid_parameter_noinfo
// 地址: 0x5f3613
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __invalid_parameter(0, 0, 0, 0, 0)
