// 函数: __errno
// 地址: 0x5f1ec6
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t* eax_2 = sub_5f5bcf()

if (eax_2 != 0)
    return &eax_2[2]

return 0x63ba68
