// 函数: ___crtDownlevelLocaleNameToLCID
// 地址: 0x6004d3
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 0)
    int32_t eax_1 = _GetTableIndexFromLocaleName(arg1)
    
    if (eax_1 s>= 0 && eax_1 u< 0xe4)
        return *((eax_1 << 3) + &data_60e320)

return 0
