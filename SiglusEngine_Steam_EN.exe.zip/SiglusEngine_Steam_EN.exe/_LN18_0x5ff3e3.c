// 函数: $LN18
// 地址: 0x5ff3e3
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t* result = __getptd()

if (result[0x24] s> 0)
    result = __getptd()
    result[0x24] -= 1

return result
