// 函数: sub_409e20
// 地址: 0x409e20
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax = arg2 * 3
*arg1 = arg2
int32_t eax_1
int32_t ecx
int32_t ecx_1
int32_t edx
int32_t edx_1
eax_1, ecx_1, edx_1 = sub_5f1ac0(eax, edx, ecx, eax, 4)
arg1[1] = eax_1
void* eax_2 = sub_5f1ac0(eax_1, edx_1, ecx_1, 0x20, 4)
int32_t ecx_2 = arg1[1]
arg1[2] = eax_2
int32_t result
int80_t st0
st0, result = sub_409e60(arg2, ecx_2, eax_2)
return result
