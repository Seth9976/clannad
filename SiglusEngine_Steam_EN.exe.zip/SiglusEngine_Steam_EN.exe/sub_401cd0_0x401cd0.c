// 函数: sub_401cd0
// 地址: 0x401cd0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return *(arg1 + 4)
