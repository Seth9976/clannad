// 函数: ??1type_info@@UAE@XZ
// 地址: 0x5f17bc
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

*arg1 = &type_info::`vftable'
return type_info::_Type_info_dtor(arg1)
