// 函数: ___doserrno
// 地址: 0x5f1e92
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t* eax_2 = sub_5f5bcf()

if (eax_2 != 0)
    return &eax_2[3]

return 0x63ba6c
