// 函数: __rtforatn20
// 地址: 0x604675
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

arg1.b = arg1.b

if (arg1.b == 0)
    arg1:1.b = arg1:1.b
else
    arg1:1.b = arg1:1.b
