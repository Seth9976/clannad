// 函数: sub_4089e0
// 地址: 0x4089e0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

void* eax = *(*(arg1 + 0x40) + 0x68)

if (eax != 0xffffffb0 && *(eax + 0x50) != 0)
    return 1

return 0
