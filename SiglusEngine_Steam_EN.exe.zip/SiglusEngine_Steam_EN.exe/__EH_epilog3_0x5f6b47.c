// 函数: __EH_epilog3
// 地址: 0x5f6b47
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1[-3]
*arg1
*arg1 = __return_addr
