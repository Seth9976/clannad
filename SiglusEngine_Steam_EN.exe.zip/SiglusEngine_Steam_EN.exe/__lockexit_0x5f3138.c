// 函数: __lockexit
// 地址: 0x5f3138
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __lock(8)
