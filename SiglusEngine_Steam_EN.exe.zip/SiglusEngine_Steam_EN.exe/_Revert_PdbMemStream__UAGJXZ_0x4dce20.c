// 函数: ?Revert@PdbMemStream@@UAGJXZ
// 地址: 0x4dce20
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return 0x80004001
