// 函数: __IsExceptionObjectToBeDestroyed
// 地址: 0x5f6f1e
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

for (int32_t* i = __getptd()[0x26]; i != 0; i = i[1])
    if (*i == arg1)
        return 0

return 1
