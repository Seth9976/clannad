// 函数: ?unexpected@@YAXXZ
// 地址: 0x5f6a19
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax = __getptd()[0x1f]

if (eax != 0)
    eax()

noreturn terminate() __tailcall
