// 函数: __cexit
// 地址: 0x5f3001
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return _doexit(0, 0, 1)
