// 函数: _write_multi_char
// 地址: 0x5fd8c2
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t i = arg2

while (i s> 0)
    i -= 1
    sub_5fd87a(arg1, arg3, arg4)
    
    if (*arg4 == 0xffffffff)
        break
