// 函数: ?_Tidy@exception@std@@AAEXXZ
// 地址: 0x5f3de4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (*(arg1 + 8) != 0)
    _free(*(arg1 + 4))

*(arg1 + 4) = 0
*(arg1 + 8) = 0
