// 函数: __cropzeros
// 地址: 0x5f9033
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __cropzeros_l(arg1, nullptr)
