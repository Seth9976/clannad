// 函数: j_sub_4daad0
// 地址: 0x4df6e0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_4daad0(arg1) __tailcall
