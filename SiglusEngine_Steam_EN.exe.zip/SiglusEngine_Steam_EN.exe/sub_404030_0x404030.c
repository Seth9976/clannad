// 函数: sub_404030
// 地址: 0x404030
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (sub_4039f0(arg1, arg2, 0) != 0)
    return 1

sub_403fc0(arg1)
return 0
