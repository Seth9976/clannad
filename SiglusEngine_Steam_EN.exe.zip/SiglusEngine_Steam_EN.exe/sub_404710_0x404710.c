// 函数: sub_404710
// 地址: 0x404710
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg2 != 0 && *(arg1 + 0x18) + arg2 s> *(arg1 + 0x14))
    return 0xffffff7d

*(arg1 + 0x18) += arg2
return 0
