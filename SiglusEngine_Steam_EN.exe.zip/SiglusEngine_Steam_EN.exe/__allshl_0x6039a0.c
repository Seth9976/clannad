// 函数: __allshl
// 地址: 0x6039a0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg3 u>= 0x40)
    return 0

if (arg3 u>= 0x20)
    return 0

return arg1 << arg3
