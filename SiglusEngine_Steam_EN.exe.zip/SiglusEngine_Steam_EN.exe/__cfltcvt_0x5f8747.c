// 函数: __cfltcvt
// 地址: 0x5f8747
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __cfltcvt_l(arg1, arg2, arg3, arg4, arg5, arg6, nullptr)
