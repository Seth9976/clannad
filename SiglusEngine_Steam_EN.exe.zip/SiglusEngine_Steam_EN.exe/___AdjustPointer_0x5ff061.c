// 函数: ___AdjustPointer
// 地址: 0x5ff061
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t* esi = arg2[1]
void* result = *arg2 + arg1

if (esi s< 0)
    return result

return result + *(*(esi + arg1) + arg2[2]) + esi
