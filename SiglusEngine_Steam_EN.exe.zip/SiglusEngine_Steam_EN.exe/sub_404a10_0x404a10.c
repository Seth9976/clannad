// 函数: sub_404a10
// 地址: 0x404a10
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 0)
    __builtin_memset(arg1, 0, 0x210)
    _free(arg1)
