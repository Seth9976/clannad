// 函数: $LN10
// 地址: 0x5f69a4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __unlock(0xe)
