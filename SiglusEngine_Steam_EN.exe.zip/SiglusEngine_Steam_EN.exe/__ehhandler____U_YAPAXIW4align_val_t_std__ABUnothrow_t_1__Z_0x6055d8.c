// 函数: __ehhandler$??_U@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x6055d8
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_5f02dd(*(arg1 - 0x1c) ^ (arg1 + 0xc))
return sub_5f6f47(0x629f38) __tailcall
