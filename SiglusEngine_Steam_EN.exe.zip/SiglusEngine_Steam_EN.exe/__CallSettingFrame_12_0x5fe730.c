// 函数: __CallSettingFrame@12
// 地址: 0x5fe730
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t ebp
int32_t var_4 = ebp
int32_t ebx
int32_t var_c = ebx
int32_t* var_14 = &var_4
int32_t var_18 = arg4
int32_t edx
__NLG_Notify1(arg2, edx, arg4, arg3 + 0xc)
int32_t esi
int32_t var_18_1 = esi
int32_t edi
int32_t var_1c = edi
int32_t result
int32_t edx_1
result, edx_1 = arg2()
int32_t ecx_1 = arg1[4]

if (ecx_1 == 0x100)
    ecx_1 = 2

int32_t var_14_1 = ecx_1
__NLG_Notify1(result, edx_1, ecx_1, arg3 + 0xc)
*arg1
return result
