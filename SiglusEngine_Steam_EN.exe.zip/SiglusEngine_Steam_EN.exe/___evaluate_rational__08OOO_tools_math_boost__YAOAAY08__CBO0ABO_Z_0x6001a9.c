// 函数: ??$evaluate_rational@$08OOO@tools@math@boost@@YAOAAY08$$CBO0ABO@Z
// 地址: 0x6001a9
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_600077(arg1, arg2, arg3, nullptr)
