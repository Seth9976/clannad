// 函数: ?what@exception@std@@UBEPBDXZ
// 地址: 0x5f3e00
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

char const* const result = *(arg1 + 4)

if (result != 0)
    return result

return "Unknown exception"
