// 函数: sub_4033b0
// 地址: 0x4033b0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = arg3 - 1

if (arg3 != 0)
    char* esi_1 = arg2
    int32_t i_1 = result + 1
    int32_t i
    
    do
        result = sub_410bd0(arg1, 8)
        *esi_1 = result.b
        esi_1 = &esi_1[1]
        i = i_1
        i_1 -= 1
    while (i != 1)

return result
