// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x5f5a22
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t ecx
return ecx()
