// 函数: ?_ValidateRead@@YAHPBXI@Z
// 地址: 0x6011b4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax_1 = neg.d(arg1)
return sbb.d(eax_1, eax_1, arg1 != 0) & 1
