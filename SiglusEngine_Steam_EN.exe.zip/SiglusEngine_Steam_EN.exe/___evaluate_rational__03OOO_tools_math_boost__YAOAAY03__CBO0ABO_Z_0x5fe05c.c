// 函数: ??$evaluate_rational@$03OOO@tools@math@boost@@YAOAAY03$$CBO0ABO@Z
// 地址: 0x5fe05c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_5fe074(arg1, arg2, arg3, nullptr)
