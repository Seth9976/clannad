// 函数: __rtforexpinf
// 地址: 0x5fbbd1
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 0)
    return float.t(0)

return data_60b9f0
