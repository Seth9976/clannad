// 函数: sub_407820
// 地址: 0x407820
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = *(arg1 + 0x30)

if (result == 0)
    return result

sub_407750(arg1)
return _free(arg1)
