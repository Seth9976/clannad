// 函数: sub_408a60
// 地址: 0x408a60
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax = *arg1

if (eax != 1)
    int32_t* ecx_1 = arg1[1]
    sub_408a90(eax, arg2, ecx_1, &ecx_1[eax], arg1[2])
