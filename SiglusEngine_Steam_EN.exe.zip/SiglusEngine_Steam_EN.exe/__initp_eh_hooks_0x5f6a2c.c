// 函数: __initp_eh_hooks
// 地址: 0x5f6a2c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = EncodePointer(terminate)
data_641744 = result
return result
