// 函数: sub_2196601
// 地址: 0x2196601
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eflags
int32_t eflags_1 = __sti(eflags)
arg1.b ^= *arg4
*arg1
int16_t* edi
int16_t temp0
temp0, edi = __insd(arg5, arg2, eflags_1)
*edi = temp0
undefined
