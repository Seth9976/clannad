// 函数: sub_402cb0
// 地址: 0x402cb0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (*(arg1 + 4) != 0)
    if (arg2 s>= 0)
        if (arg2 s< *(arg1 + 0x34))
            return *(arg1 + 0x48) + (arg2 << 5)
        
        return 0
    
    if (*(arg1 + 0x58) s>= 3)
        return (*(arg1 + 0x60) << 5) + *(arg1 + 0x48)

return *(arg1 + 0x48)
