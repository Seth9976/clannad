// 函数: __invalid_parameter
// 地址: 0x5f35e8
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax = DecodePointer(data_640fec)

if (eax != 0)
    jump(eax)

int32_t var_8_1 = arg5
int32_t var_c = arg4
int32_t var_10 = arg3
int32_t var_14 = arg2
int32_t var_18 = arg1
__invoke_watson()
noreturn
