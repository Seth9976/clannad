// 函数: sub_40b2b0
// 地址: 0x40b2b0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return (&data_63af84)[arg1]
