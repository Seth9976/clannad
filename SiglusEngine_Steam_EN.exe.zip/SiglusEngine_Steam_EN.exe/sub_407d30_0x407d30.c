// 函数: sub_407d30
// 地址: 0x407d30
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t* eax = *arg2
int32_t ecx_1 = **arg1
int32_t edx_1 = *eax
return neg.d(sbb.d(eax, eax, edx_1 u< ecx_1)) - neg.d(sbb.d(ecx_1, ecx_1, ecx_1 u< edx_1))
