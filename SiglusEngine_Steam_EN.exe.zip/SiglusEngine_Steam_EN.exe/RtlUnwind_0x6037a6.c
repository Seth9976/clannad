// 函数: RtlUnwind
// 地址: 0x6037a6
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
