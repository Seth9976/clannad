// 函数: __ehhandler$??2@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x605b2f
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_5f02dd(*(arg1 - 0x14) ^ (arg1 + 0xc))
return sub_5f6f47(0x62abc8) __tailcall
