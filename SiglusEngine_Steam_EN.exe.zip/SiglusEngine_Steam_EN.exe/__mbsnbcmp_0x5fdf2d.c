// 函数: __mbsnbcmp
// 地址: 0x5fdf2d
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __mbsnbcmp_l(arg1, arg2, arg3, nullptr)
