// 函数: ___onexitinit
// 地址: 0x5f18d4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t* eax = sub_5f6a6e(0x20, 4)
int32_t eax_1 = EncodePointer(eax)
data_20f4590 = eax_1
data_20f458c = eax_1

if (eax == 0)
    return 0x18

*eax = 0
return 0
