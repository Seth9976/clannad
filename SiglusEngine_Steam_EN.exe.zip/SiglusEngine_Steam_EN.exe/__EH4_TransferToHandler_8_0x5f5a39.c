// 函数: @_EH4_TransferToHandler@8
// 地址: 0x5f5a39
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

__NLG_Notify(arg1, arg2, 1)
jump(arg1)
