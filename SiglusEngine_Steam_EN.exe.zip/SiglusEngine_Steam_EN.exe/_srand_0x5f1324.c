// 函数: _srand
// 地址: 0x5f1324
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t* result = __getptd()
result[5] = arg1
return result
