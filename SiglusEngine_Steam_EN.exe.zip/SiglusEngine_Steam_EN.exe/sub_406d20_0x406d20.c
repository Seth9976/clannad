// 函数: sub_406d20
// 地址: 0x406d20
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return fconvert.t((arg1 & 0xbf800000) | 0x3f800000)
