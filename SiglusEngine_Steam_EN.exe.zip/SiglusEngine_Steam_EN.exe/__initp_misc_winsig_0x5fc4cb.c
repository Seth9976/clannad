// 函数: __initp_misc_winsig
// 地址: 0x5fc4cb
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_6419dc = arg1
data_6419e0 = arg1
data_6419e4 = arg1
data_6419e8 = arg1
return arg1
