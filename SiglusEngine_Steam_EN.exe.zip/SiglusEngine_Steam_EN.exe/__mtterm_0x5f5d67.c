// 函数: __mtterm
// 地址: 0x5f5d67
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t eax_1 = data_63be70

if (eax_1 != 0xffffffff)
    sub_5f3674(eax_1)
    data_63be70 = 0xffffffff

return __mtdeletelocks() __tailcall
