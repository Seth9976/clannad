// 函数: __CIpow_pentium4
// 地址: 0x5faf30
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t edi
return __pow_pentium4(edi, fconvert.d(arg2), fconvert.d(arg1))
