// 函数: sub_40b560
// 地址: 0x40b560
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = 0

if (arg1 != 0)
    uint32_t i = arg1 - 1
    
    if (arg1 != 1)
        do
            result += 1
            i u>>= 1
        while (i != 0)

return result
