// 函数: __swprintf_c
// 地址: 0x5f090b
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

void arg_10
return __vsprintf_s_l(arg1, arg2, arg3, 0, &arg_10)
