// 函数: _fread
// 地址: 0x5f0b8d
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return _fread_s(arg1, 0xffffffff, arg2, arg3, arg4)
