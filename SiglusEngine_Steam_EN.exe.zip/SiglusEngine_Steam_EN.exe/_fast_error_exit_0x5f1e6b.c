// 函数: _fast_error_exit
// 地址: 0x5f1e6b
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (data_641870 == 1)
    __FF_MSGBANNER()

__NMSG_WRITE(arg1)
___crtExitProcess(0xff)
noreturn
