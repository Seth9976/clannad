// 函数: __initp_misc_rand_s
// 地址: 0x5fc6dc
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_6419f0 = arg1
return arg1
