// 函数: ___report_rangecheckfailure
// 地址: 0x5f082f
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t ebp
int32_t var_4 = ebp
int32_t var_8 = 8
int32_t esi
int32_t edi
___report_securityfailure(&var_4, esi, edi)
noreturn
