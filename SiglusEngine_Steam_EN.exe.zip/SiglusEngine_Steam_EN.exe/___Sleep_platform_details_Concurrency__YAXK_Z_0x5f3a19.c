// 函数: ?__Sleep@platform@details@Concurrency@@YAXK@Z
// 地址: 0x5f3a19
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return Sleep(arg1)
