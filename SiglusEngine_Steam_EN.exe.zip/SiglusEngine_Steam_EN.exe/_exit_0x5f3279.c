// 函数: _exit
// 地址: 0x5f3279
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

_doexit(status, 0, 0)
