// 函数: __seh_longjmp_unwind4@4
// 地址: 0x5f5a06
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

*arg1
return __local_unwind4(arg1[0xa], arg1[6], arg1[7])
