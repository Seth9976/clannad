// 函数: __unlock
// 地址: 0x5fc354
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return LeaveCriticalSection(*((arg1 << 3) + &data_63c740))
