// 函数: __ehhandler$??0system_error@std@@QAE@HABVerror_category@1@PBD@Z
// 地址: 0x605620
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_5f02dd(*(arg1 - 0x34) ^ (arg1 + 0xc))
sub_5f02dd(*(arg1 - 4) ^ (arg1 + 0xc))
return sub_5f6f47(0x629f94) __tailcall
