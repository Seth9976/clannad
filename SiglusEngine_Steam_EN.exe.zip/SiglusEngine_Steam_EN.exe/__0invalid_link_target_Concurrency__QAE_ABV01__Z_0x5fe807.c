// 函数: ??0invalid_link_target@Concurrency@@QAE@ABV01@@Z
// 地址: 0x5fe807
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

struct std::exception::std::bad_exception::VTable** result = arg1
std::exception::exception(arg1, arg2)
*result = &std::bad_exception::`vftable'{for `std::exception'}
return result
