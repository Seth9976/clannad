// 函数: sub_2177380
// 地址: 0x2177380
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return 0
