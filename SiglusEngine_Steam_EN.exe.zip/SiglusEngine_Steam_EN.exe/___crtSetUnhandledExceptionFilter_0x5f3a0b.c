// 函数: ___crtSetUnhandledExceptionFilter
// 地址: 0x5f3a0b
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return SetUnhandledExceptionFilter(arg1)
