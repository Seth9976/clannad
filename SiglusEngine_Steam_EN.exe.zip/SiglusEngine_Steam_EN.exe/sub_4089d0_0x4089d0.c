// 函数: sub_4089d0
// 地址: 0x4089d0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

__builtin_memset(arg1, 0, 0x30)
return 0
