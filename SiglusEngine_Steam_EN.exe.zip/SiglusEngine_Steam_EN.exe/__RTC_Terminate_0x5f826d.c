// 函数: __RTC_Terminate
// 地址: 0x5f826d
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

for (void* const i = &data_629dbc; i u< &data_629dbc; i += 4)
    int32_t eax = *i
    
    if (eax != 0)
        eax()
