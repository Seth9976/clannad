// 函数: __statfp
// 地址: 0x5faf1b
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int16_t ecx
int16_t var_8 = ecx
bool c0
bool c1
bool c2
bool c3
return sx.d((c0 ? 1 : 0) << 8 | (c1 ? 1 : 0) << 9 | (c2 ? 1 : 0) << 0xa | (c3 ? 1 : 0) << 0xe)
