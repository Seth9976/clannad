// 函数: __NLG_Notify
// 地址: 0x5fe345
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_63c868 = arg3
data_63c864 = arg1
data_63c86c = arg2
int32_t var_c = arg2
int32_t var_10 = arg3
return arg1
