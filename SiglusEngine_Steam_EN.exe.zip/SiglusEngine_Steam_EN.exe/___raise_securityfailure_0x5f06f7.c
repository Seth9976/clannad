// 函数: ___raise_securityfailure
// 地址: 0x5f06f7
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_640fa4 = IsDebuggerPresent()
sub_5f364e()
___crtUnhandledException(arg1)

if (data_640fa4 == 0)
    sub_5f364e()

sub_5f3a27(0xc0000409)
noreturn
