// 函数: __CIlog10_pentium4
// 地址: 0x605220
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_60523e(zx.o(fconvert.d(arg1)))
