// 函数: ??4exception@std@@QAEAAV01@ABV01@@Z
// 地址: 0x5f3d4e
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != arg2)
    std::exception::_Tidy(arg1)
    
    if (*(arg2 + 8) == 0)
        *(arg1 + 4) = *(arg2 + 4)
    else
        sub_5f3da6(arg1, *(arg2 + 4))

return arg1
