// 函数: sub_40c4c0
// 地址: 0x40c4c0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 0)
    __builtin_memset(arg1, 0, 0x714)
    _free(arg1)
