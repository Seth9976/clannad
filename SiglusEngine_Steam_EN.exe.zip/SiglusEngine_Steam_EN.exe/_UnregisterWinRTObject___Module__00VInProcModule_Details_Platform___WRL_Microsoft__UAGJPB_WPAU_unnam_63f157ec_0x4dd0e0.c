// 函数: ?UnregisterWinRTObject@?$Module@$00VInProcModule@Details@Platform@@@WRL@Microsoft@@UAGJPB_WPAU<unnamed-type-RO_REGISTRATION_COOKIE>@@@Z
// 地址: 0x4dd0e0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return 0x80004001
