// 函数: ___set_app_type
// 地址: 0x5fc4b1
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_6419d8 = arg1
return arg1
