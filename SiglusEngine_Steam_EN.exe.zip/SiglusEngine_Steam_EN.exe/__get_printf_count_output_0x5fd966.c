// 函数: __get_printf_count_output
// 地址: 0x5fd966
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result
result.b = data_6419f4 == (__security_cookie | 1)
return result
