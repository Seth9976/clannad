// 函数: __c_exit
// 地址: 0x5f2ff2
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return _doexit(0, 1, 1)
