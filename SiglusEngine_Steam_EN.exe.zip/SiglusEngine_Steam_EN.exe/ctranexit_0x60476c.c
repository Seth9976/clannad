// 函数: ctranexit
// 地址: 0x60476c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

*(arg1 - 0x2c8) &= 0xfe
long double x87_r0
return cintrinexit(arg1, x87_r0) __tailcall
