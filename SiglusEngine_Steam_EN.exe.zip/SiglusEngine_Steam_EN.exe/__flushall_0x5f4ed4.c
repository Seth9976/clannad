// 函数: __flushall
// 地址: 0x5f4ed4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return _flsall(1)
