// 函数: ?Clone@PdbMemStream@@UAGJPAPAUIStream@@@Z
// 地址: 0x4dcef0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return 0x80004001
