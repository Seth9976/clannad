// 函数: __set_pgmptr
// 地址: 0x5f8164
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_641108 = arg1
return arg1
