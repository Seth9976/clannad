// 函数: __CIasin_default
// 地址: 0x604cb0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int16_t x87control
return sub_604ccd(x87control, arg1)
