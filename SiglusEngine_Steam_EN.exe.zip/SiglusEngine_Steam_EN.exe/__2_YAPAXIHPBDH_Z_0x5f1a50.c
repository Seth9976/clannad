// 函数: ??2@YAPAXIHPBDH@Z
// 地址: 0x5f1a50
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return j__free(arg1)
