// 函数: ??_Gtype_info@@UAEPAXI@Z
// 地址: 0x5f17e8
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

type_info::~type_info(arg1)

if ((arg2 & 1) != 0)
    j__free(arg1)

return arg1
