// 函数: __initp_misc_cfltcvt_tab
// 地址: 0x5f920c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result

for (int32_t i = 0; i u< 0x28; i += 4)
    result = EncodePointer(*(i + &data_63c5d0))
    *(i + &data_63c5d0) = result

return result
