// 函数: __rtindfpop
// 地址: 0x5fbe36
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_60ba50

if (*(arg1 - 0x90) s> 0)
    return 

return sub_5fbe49(arg1) __tailcall
