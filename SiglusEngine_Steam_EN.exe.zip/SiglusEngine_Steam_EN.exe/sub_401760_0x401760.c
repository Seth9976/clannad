// 函数: sub_401760
// 地址: 0x401760
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = *arg1

if (result == 0)
    return result

arg1[0xb1](result, arg2, arg3, 0)
arg1[2] = arg2
arg1[3] = arg3
return sub_410750(&arg1[6])
