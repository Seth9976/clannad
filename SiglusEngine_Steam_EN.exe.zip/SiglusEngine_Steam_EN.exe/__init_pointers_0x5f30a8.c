// 函数: __init_pointers
// 地址: 0x5f30a8
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t eax = EncodePointer(nullptr)
__initp_misc_purevirt(eax)
__initp_misc_invarg(eax)
___set_app_type(eax)
__initp_misc_winsig(eax)
int32_t var_18 = eax
__initp_eh_hooks()
__initp_misc_rand_s(eax)
return sub_5f3765() __tailcall
