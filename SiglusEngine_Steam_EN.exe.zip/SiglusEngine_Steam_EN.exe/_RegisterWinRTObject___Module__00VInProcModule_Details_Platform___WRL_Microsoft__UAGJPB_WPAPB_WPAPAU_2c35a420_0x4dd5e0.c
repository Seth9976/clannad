// 函数: ?RegisterWinRTObject@?$Module@$00VInProcModule@Details@Platform@@@WRL@Microsoft@@UAGJPB_WPAPB_WPAPAU<unnamed-type-RO_REGISTRATION_COOKIE>@@I@Z
// 地址: 0x4dd5e0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return 0x80004001
