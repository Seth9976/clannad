// 函数: __CIcos_pentium4
// 地址: 0x605070
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_60508e(zx.o(fconvert.d(arg1)))
