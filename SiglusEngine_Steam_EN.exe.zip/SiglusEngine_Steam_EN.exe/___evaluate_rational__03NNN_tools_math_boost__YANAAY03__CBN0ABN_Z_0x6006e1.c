// 函数: ??$evaluate_rational@$03NNN@tools@math@boost@@YANAAY03$$CBN0ABN@Z
// 地址: 0x6006e1
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_6005ec(arg1, arg2, arg3, nullptr)
