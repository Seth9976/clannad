// 函数: _tolower
// 地址: 0x5ffe62
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (data_641878 != 0)
    return __tolower_l(arg1, nullptr)

if (arg1 - 0x41 u> 0x19)
    return arg1

return arg1 + 0x20
