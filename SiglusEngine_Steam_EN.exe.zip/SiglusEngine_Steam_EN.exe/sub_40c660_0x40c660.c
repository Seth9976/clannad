// 函数: sub_40c660
// 地址: 0x40c660
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t i = arg1
int32_t result = 0

for (; i != 0; i u>>= 1)
    result += i & 1

return result
