// 函数: $LN37
// 地址: 0x5fc668
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t entry_ebx

if (entry_ebx != 0)
    __unlock(0)
