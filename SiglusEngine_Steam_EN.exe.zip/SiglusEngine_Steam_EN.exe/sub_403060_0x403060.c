// 函数: sub_403060
// 地址: 0x403060
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

*arg1 = 0
arg1[1] = 0
arg1[2] = 0
arg1[3] = 0
return 0
