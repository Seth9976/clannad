// 函数: __ismbblead
// 地址: 0x5ffbba
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_5ffb60(nullptr, arg1, 0, 4)
