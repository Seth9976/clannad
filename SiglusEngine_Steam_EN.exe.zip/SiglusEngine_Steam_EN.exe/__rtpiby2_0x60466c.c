// 函数: __rtpiby2
// 地址: 0x60466c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return data_60ba5a
