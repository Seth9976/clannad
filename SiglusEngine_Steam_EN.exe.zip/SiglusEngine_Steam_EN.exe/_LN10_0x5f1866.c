// 函数: $LN10
// 地址: 0x5f1866
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t entry_ebx

if (arg1 == 0)
    __ArrayUnwind(arg3, entry_ebx, arg4, *(arg2 + 0x14))
