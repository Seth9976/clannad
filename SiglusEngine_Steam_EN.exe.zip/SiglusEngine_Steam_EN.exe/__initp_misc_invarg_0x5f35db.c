// 函数: __initp_misc_invarg
// 地址: 0x5f35db
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

data_640fec = arg1
return arg1
