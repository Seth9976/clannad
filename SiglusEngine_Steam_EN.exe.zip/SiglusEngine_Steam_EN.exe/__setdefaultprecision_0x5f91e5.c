// 函数: __setdefaultprecision
// 地址: 0x5f91e5
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = __controlfp_s(nullptr, 0x10000, 0x30000)

if (result == 0)
    return result

int32_t var_18
__builtin_memset(&var_18, 0, 0x14)
__invoke_watson()
noreturn
