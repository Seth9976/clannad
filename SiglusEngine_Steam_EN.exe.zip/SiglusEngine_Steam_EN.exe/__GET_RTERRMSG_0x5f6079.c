// 函数: __GET_RTERRMSG
// 地址: 0x5f6079
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

for (int32_t i = 0; i u< 0x17; i += 1)
    if (arg1 == *((i << 3) + &data_606c68))
        return (&data_606c6c)[i * 2]

return 0
