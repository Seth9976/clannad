// 函数: __fpmath
// 地址: 0x5f21a1
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t result = __cfltcvt_init()

if (arg1 != 0)
    result = __setdefaultprecision()

__fnclex()
return result
