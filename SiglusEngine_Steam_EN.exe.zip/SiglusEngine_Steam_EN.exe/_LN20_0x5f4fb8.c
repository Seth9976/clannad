// 函数: $LN20
// 地址: 0x5f4fb8
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __unlock(1)
