// 函数: ?DeleteMod@DBI1@@UAEHPBD@Z
// 地址: 0x4e12b0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return 1
