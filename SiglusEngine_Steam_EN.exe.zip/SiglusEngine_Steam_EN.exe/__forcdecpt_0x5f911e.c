// 函数: __forcdecpt
// 地址: 0x5f911e
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __forcdecpt_l(arg1, nullptr)
