// 函数: _start
// 地址: 0x5f1d11
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

___security_init_cookie()
int32_t esi
int32_t edi
return ___tmainCRTStartup(esi, edi) __tailcall
