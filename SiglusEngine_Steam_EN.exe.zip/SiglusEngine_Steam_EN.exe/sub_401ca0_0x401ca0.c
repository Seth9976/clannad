// 函数: sub_401ca0
// 地址: 0x401ca0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_403d90(arg1 + 0x1e0)
sub_403980(arg1 + 0x250)
*(arg1 + 0x58) = 2
return 0
