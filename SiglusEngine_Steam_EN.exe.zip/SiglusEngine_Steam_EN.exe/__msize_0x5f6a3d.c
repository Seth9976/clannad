// 函数: __msize
// 地址: 0x5f6a3d
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 0)
    return HeapSize(data_641100, HEAP_NONE, arg1)

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
