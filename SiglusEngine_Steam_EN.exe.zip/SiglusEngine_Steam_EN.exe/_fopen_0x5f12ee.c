// 函数: _fopen
// 地址: 0x5f12ee
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __fsopen(arg1, arg2, 0x40)
