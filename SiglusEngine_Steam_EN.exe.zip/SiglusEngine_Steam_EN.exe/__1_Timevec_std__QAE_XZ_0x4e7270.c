// 函数: ??1_Timevec@std@@QAE@XZ
// 地址: 0x4e7270
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return _free(*arg1)
