// 函数: sub_409e60
// 地址: 0x409e60
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 1)
    sub_409e80(arg1, arg2 + (arg1 << 2), arg3)
