// 函数: ___initmbctable
// 地址: 0x5f7351
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (data_20f4594 == 0)
    sub_5f76ae(0xfffffffd)
    data_20f4594 = 1

return 0
