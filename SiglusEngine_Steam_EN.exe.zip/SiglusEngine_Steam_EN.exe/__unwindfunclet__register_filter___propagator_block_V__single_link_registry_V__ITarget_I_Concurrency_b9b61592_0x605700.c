// 函数: __unwindfunclet$?register_filter@?$propagator_block@V?$single_link_registry@V?$ITarget@I@Concurrency@@@Concurrency@@V?$multi_link_registry@V?$ISource@W4agent_status@Concurrency@@@Concurrency@@@2@V?$ordered_message_processor@I@2@@Concurrency@@IAEXABV?$function@$$A6A_NABW4agent_status@Concurrency@@@Z@std@@@Z$1
// 地址: 0x605700
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return j_sub_4dfde0(*(arg1 - 0x10)) __tailcall
