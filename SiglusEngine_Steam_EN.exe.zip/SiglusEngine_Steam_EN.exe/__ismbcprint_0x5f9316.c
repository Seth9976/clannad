// 函数: __ismbcprint
// 地址: 0x5f9316
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_5f92dc(arg1, nullptr)
