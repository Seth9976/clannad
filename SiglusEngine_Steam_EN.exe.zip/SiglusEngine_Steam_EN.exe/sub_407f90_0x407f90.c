// 函数: sub_407f90
// 地址: 0x407f90
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_410990(arg3, *(*(arg1 + 0x14) + (arg2 << 2)), *(*(*(arg1 + 0xc) + 8) + (arg2 << 2)))
return *(*(*(arg1 + 0xc) + 8) + (arg2 << 2))
