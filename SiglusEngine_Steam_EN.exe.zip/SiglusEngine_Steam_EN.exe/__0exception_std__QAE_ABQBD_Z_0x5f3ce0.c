// 函数: ??0exception@std@@QAE@ABQBD@Z
// 地址: 0x5f3ce0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

arg1[1] = 0
*arg1 = &std::exception::`vftable'
arg1[2].b = 0
sub_5f3da6(arg1, *arg2)
return arg1
