// 函数: __getptd
// 地址: 0x5f5bb7
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

uint32_t* result = sub_5f5bcf()

if (result != 0)
    return result

__amsg_exit(0x10)
noreturn
