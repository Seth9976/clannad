// 函数: j__free
// 地址: 0x5f1a1d
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return j__free(arg1) __tailcall
