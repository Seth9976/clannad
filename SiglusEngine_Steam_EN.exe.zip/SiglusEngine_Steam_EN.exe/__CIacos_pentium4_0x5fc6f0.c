// 函数: __CIacos_pentium4
// 地址: 0x5fc6f0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

double var_10 = fconvert.d(arg1)
uint64_t xmm5[0x2]
int64_t xmm6
return start(zx.o(var_10), xmm5, xmm6, var_10)
