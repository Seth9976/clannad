// 函数: __mbsstr
// 地址: 0x5f1bff
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __mbsstr_l(arg1, arg2, nullptr)
