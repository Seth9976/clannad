// 函数: __mbsnbcpy_s
// 地址: 0x5f1cf6
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __mbsnbcpy_s_l(arg1, arg2, arg3, arg4, nullptr)
