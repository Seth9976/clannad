// 函数: $LN17
// 地址: 0x5f3264
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (*(arg1 + 0x10) != 0)
    __unlock(8)
