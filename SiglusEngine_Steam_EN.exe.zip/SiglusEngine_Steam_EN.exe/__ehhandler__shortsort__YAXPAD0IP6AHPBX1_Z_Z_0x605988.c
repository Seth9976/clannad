// 函数: __ehhandler$?shortsort@@YAXPAD0IP6AHPBX1@Z@Z
// 地址: 0x605988
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_5f02dd(*(arg1 - 0x18) ^ (arg1 + 0xc))
sub_5f02dd(*(arg1 - 4) ^ (arg1 + 0xc))
return sub_5f6f47(0x62a3a8) __tailcall
