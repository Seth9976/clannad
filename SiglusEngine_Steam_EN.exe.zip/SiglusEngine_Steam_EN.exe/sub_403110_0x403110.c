// 函数: sub_403110
// 地址: 0x403110
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t edx
int32_t result = sub_5f1ac0(0, edx, __builtin_memset(arg1, 0, 0x20), 1, 0xe50)
*(arg1 + 0x1c) = result
return result
