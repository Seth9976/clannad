// 函数: _isdigit
// 地址: 0x5ffcf4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (data_641878 != 0)
    return __isdigit_l(arg1, nullptr)

return zx.d((*data_63c5a0)[arg1]) & 4
