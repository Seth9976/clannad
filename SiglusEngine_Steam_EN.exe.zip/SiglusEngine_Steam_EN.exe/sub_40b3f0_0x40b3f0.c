// 函数: sub_40b3f0
// 地址: 0x40b3f0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg1 != 0)
    __builtin_memset(arg1, 0, 0xc88)
    _free(arg1)
