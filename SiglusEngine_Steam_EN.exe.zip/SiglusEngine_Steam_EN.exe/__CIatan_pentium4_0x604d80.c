// 函数: __CIatan_pentium4
// 地址: 0x604d80
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

double var_10 = fconvert.d(arg1)
return sub_604d9e(zx.o(var_10), var_10)
