// 函数: j__free
// 地址: 0x5f09c3
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return _free(arg1) __tailcall
