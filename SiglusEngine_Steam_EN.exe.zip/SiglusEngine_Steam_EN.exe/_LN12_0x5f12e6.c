// 函数: $LN12
// 地址: 0x5f12e6
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __unlock_file(arg1)
