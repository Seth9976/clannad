// 函数: __allmul
// 地址: 0x5f2250
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if ((arg4 | arg2) == 0)
    return arg1 * arg3

int32_t result
int32_t edx
edx:result = mulu.dp.d(arg1, arg3)
return result
