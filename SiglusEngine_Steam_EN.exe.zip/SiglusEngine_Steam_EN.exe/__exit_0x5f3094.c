// 函数: __exit
// 地址: 0x5f3094
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

_doexit(status, 1, 0)
