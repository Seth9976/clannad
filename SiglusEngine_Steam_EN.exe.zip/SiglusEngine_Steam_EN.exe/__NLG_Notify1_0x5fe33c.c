// 函数: __NLG_Notify1
// 地址: 0x5fe33c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t var_8 = arg3
data_63c868 = arg3
data_63c864 = arg1
data_63c86c = arg4
int32_t var_c = arg4
int32_t var_10 = arg3
return arg1
