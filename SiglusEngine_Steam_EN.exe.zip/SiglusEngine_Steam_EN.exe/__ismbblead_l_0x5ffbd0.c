// 函数: __ismbblead_l
// 地址: 0x5ffbd0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return sub_5ffb60(arg2, arg1, 0, 4)
