// 函数: __shift
// 地址: 0x5f91bd
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

if (arg2 != 0)
    _memcpy(arg1 + arg2, arg1, _strlen(arg1) + 1)
