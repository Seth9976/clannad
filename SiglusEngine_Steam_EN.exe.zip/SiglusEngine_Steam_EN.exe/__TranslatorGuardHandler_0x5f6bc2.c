// 函数: __TranslatorGuardHandler
// 地址: 0x5f6bc2
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t var_8 = arg3
sub_5f02dd(*(arg5 + 8) ^ arg5)

if ((arg4->ExceptionFlags & 0x66) != 0)
    *(arg5 + 0x24) = 1
    return 1

sub_5ff3fd(arg4, *(arg5 + 0x10), arg6, nullptr, *(arg5 + 0xc), *(arg5 + 0x14), *(arg5 + 0x18), 1)

if (*(arg5 + 0x24) == 0)
    sub_5f6e4f(arg5, arg4)

int32_t var_10_2 = 0
sub_5f6cc8(0x123, &var_8, 0, 0, 0, 0)
*(arg5 + 0x1c)
*(arg5 + 0x20)
jump(var_8)
