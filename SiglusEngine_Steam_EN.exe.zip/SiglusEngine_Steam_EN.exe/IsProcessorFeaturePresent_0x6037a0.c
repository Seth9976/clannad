// 函数: IsProcessorFeaturePresent
// 地址: 0x6037a0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return IsProcessorFeaturePresent(ProcessorFeature) __tailcall
