// 函数: __unwindfunclet$?_Init@locale@std@@CAPAV_Locimp@12@_N@Z$1
// 地址: 0x605730
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t var_4 = 0x640fa8
return operator new[](*(arg1 - 0x14))
