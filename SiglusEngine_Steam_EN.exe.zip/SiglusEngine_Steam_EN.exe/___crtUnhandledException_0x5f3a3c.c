// 函数: ___crtUnhandledException
// 地址: 0x5f3a3c
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

SetUnhandledExceptionFilter(nullptr)
return UnhandledExceptionFilter(arg1)
