// 函数: @_EH4_LocalUnwind@16
// 地址: 0x5f5a6b
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return __local_unwind4(arg4, arg1, arg2)
