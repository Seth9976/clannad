// 函数: sub_4078a0
// 地址: 0x4078a0
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

__builtin_memset(arg1, 0, 0x2c)
arg1[3] = arg2
arg1[1] = arg2[1]
arg1[2] = arg2[1]
*arg1 = *arg2
arg1[5] = sub_407370(arg2[2], arg2[1], 0)
arg1[4] = sub_407560(arg2, arg2[1], nullptr)
return 0
