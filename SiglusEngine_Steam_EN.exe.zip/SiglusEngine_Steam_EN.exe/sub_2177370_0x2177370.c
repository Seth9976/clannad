// 函数: sub_2177370
// 地址: 0x2177370
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

return arg1
