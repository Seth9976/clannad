// 函数: __fassign
// 地址: 0x5f90c4
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

int32_t var_8 = 0
int32_t eax
int32_t ecx
int32_t edx
return __fassign_l(eax, edx, ecx, arg1, arg2, arg3)
