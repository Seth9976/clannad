// 函数: __ehhandler$___std_fs_get_file_id@8
// 地址: 0x60540a
// 来自: E:\Download\CYZD_GALGAME_PACKAGE\CLANNAD\SiglusEngine_Steam.exe

sub_5f02dd(*(arg1 - 0x20) ^ (arg1 + 0xc))
return sub_5f6f47(0x629ddc) __tailcall
